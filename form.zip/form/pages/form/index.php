<?php

gatekeeper();
if (is_callable('group_gatekeeper')) 
   group_gatekeeper();

$owner = elgg_get_page_owner_entity();
$user_guid = elgg_get_logged_in_user_guid();
$user = get_entity($user_guid);

$title = elgg_echo(sprintf(elgg_echo('form:user'),$owner->name));

$group_guid = $owner->getGUID();
$group_owner_guid = $owner->owner_guid;

$operator=false;
if (($group_owner_guid==$user_guid)||(check_entity_relationship($user_guid,'group_admin',$group_guid))){
   $operator=true;
}

if ($operator)
   elgg_register_title_button('form','add');

$forms = elgg_get_entities(array('type'=>'object','subtype'=>'form','limit'=>false,'container_guid'=>$owner->getGUID()));
			
if (!$operator){
   $i=0;
   $j=0;
   $my_not_finished_forms=array();
   $my_finished_forms=array();
   foreach($forms as $form){
      if ($form->created){	
         $container_guid  = $form->container_guid;
         if ($form->subgroups){
	    $user_subgroups = elgg_get_entities_from_relationship(array('type_subtype_pairs' => array('group' => 'lbr_subgroup'),'container_guids' => $container_guid,'relationship' => 'member','inverse_relationship' => false,'relationship_guid' => $user_guid));
	    if ($user_subgroups) {
	       $user_subgroup_guid=$user_subgroups[0]->getGUID();
	       $options = array('relationship' => 'form_answer', 'relationship_guid' => $form->getGUID(),'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_answer', 'order_by' => 'e.time_created desc', 'limit' => 0, 'container_guid' => $user_subgroup_guid); 
	    }
         } else {
	    $options = array('relationship' => 'form_answer', 'relationship_guid' => $form->getGUID(),'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_answer', 'order_by' => 'e.time_created desc', 'limit' => 0, 'owner_guid' => $user_guid);
         }
         $user_response="";
	 if ($options)
            $user_responses=elgg_get_entities_from_relationship($options);
         if (!empty($user_responses)){
	    $user_response=$user_responses[0];
            $my_finished_forms[$j]=$form;
            $my_finished_forms_time[$j]=$time;
            $j=$j+1;
	 } else {
	    if ((($form->subgroups) && ($user_subgroup_guid))||(!$form->subgroups)) {
	       $my_not_finished_forms[$i]=$form;
               $i=$i+1;
	    }
	 }
      }
   }
   $num_not_finished_forms=$i;
   $num_finished_forms=$j;
}
	
$content = "";
	
if ($operator){
   foreach ($forms as $form){
      $content .= elgg_view("object/form", array('full_view' => false, 'entity' => $form, 'user_type' => "operator"));
   }
} else {
   $i=0;
   while ($i<$num_not_finished_forms){
      $content .= elgg_view("object/form", array('full_view' => false, 'entity' => $my_not_finished_forms[$i], 'user_type' => "not_finished"));
      $i=$i+1;
   }
   $j=0;
   while ($j<$num_finished_forms){   
      $content .= elgg_view("object/form", array('full_view' => false, 'entity' => $my_finished_forms[$j], 'user_type' => "finished"));
      $j=$j+1;
   }
}

$params = array('content' => $content,'title' => $title);

if (elgg_instanceof($owner, 'group')) {
   $params['filter'] = '';
}

$body = elgg_view_layout('content', $params);
echo elgg_view_page($title, $body);
		
?>