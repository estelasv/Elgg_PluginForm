<?php
	
gatekeeper();
if (is_callable('group_gatekeeper')) 
   group_gatekeeper();
	
$formpost = get_input('formpost');
$form = get_entity($formpost);
$user_guid = elgg_get_logged_in_user_guid();
$user = get_entity($user_guid);

$container_guid = $form->container_guid;
$container = get_entity($container_guid);

elgg_set_page_owner_guid($container_guid);

elgg_push_breadcrumb($form->title, $form->getURL());
elgg_push_breadcrumb(elgg_echo('edit'));

if ($form && $form->canEdit()){
   $title = elgg_echo('form:editpost');
   $content = elgg_view("forms/form/edit", array('entity' => $form));
} 

$body = elgg_view_layout('content', array('filter' => '','content' => $content,'title' => $title));
echo elgg_view_page($title, $body);
		
?>