<?php
	
gatekeeper();
if (is_callable('group_gatekeeper')) 
   group_gatekeeper();
	
$formpost = get_input('formpost');
$form = get_entity($formpost);

$container_guid = $form->container_guid;
$container = get_entity($container_guid);

elgg_set_page_owner_guid($container_guid);

elgg_push_breadcrumb($form->title, $form->getURL());

if ($form && $form->canEdit()){
   $title = elgg_echo('form:addquestionpost');
   $content = elgg_view("forms/form/add_question", array('entity' => $form));
} 

$body = elgg_view_layout('content', array('filter' => '','content' => $content,'title' => $title));
echo elgg_view_page($title, $body);
		
?>