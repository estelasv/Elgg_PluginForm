<?php

gatekeeper();
if (is_callable('group_gatekeeper')) 
   group_gatekeeper();

$formpost = get_input('guid');
$form = get_entity($formpost);
$offset = get_input('offset');
if (empty($offset))
   $offset = 0;

//Show answers by operator
$this_user_guid = get_input('this_user_guid');

if ($form) {
   $container_guid = $form->container_guid;
   $container = get_entity($container_guid);
   elgg_set_page_owner_guid($container_guid);

   elgg_push_breadcrumb($container->name, "form/group/$container_guid");
   if (empty($this_user_guid))
      elgg_push_breadcrumb($form->title);
   else
      elgg_push_breadcrumb($form->title,$form->getURL()."?offset=".$offset);

   $owner = $form->getOwnerEntity();
   $owner_guid = $owner->getGUID();
   $user_guid = elgg_get_logged_in_user_guid();
   $user = get_entity($user_guid);
   $group_guid=$form->container_guid;
   $group = get_entity($group_guid);
   $group_owner_guid = $group->owner_guid;

   $operator=false;
   if (($owner_guid==$user_guid)||($group_owner_guid==$user_guid)||(check_entity_relationship($user_guid,'group_admin',$group_guid))){
      $operator=true;
   }

   if (!$operator){
      //$title = elgg_echo('form:answerpost');
      $title = elgg_echo('form:response');
   } else { 
      if (empty($this_user_guid))
         $title = elgg_echo('form:showresultspost');
      else
         $title = elgg_echo('form:response');		
   }
  
   $content = elgg_view("object/form",array('full_view' => true, 'entity' => $form,'entity_owner' => $container,'offset'=>$offset,'this_user_guid'=>$this_user_guid));
   $body = elgg_view_layout('content', array('filter' => '','content' => $content,'title' => $title));
   echo elgg_view_page($title, $body);

} else {
   register_error( elgg_echo('form:notfound'));
   forward();
}
		
?>