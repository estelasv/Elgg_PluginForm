<?php

$full = elgg_extract('full_view', $vars, FALSE);
$form = elgg_extract('entity', $vars, FALSE);
$user_type = elgg_extract('user_type', $vars, FALSE);

if (!$form) {
   return TRUE;
}

$owner = $form->getOwnerEntity();
$owner_icon = elgg_view_entity_icon($owner, 'tiny');
$owner_link = elgg_view('output/url', array('href' => $owner->getURL(),'text' => $owner->name,'is_trusted' => true));
$author_text = elgg_echo('byline', array($owner_link));
$tags = elgg_view('output/tags', array('tags' => $form->tags));
$date = elgg_view_friendly_time($form->time_created);
$metadata = elgg_view_menu('entity', array('entity' => $form,'handler' => 'form','sort_by' => 'priority','class' => 'elgg-menu-hz'));
$subtitle = "$author_text $date $comments_link";

//////////////////////////////////////////////////
//Form information

$owner_guid = $owner->getGUID();
$user_guid = elgg_get_logged_in_user_guid();
$user = get_entity($user_guid);
$group_guid=$form->container_guid;
$group = get_entity($group_guid);
$group_owner_guid = $group->owner_guid;
$formpost = $form->getGUID();
$created = $form->created;
$opened = form_check_status($form);

$operator=false;
if (($owner_guid==$user_guid)||($group_owner_guid==$user_guid)||(check_entity_relationship($user_guid,'group_admin',$group_guid))){
   $operator=true;
}

//Open interval
if ($opened){
   if ((strcmp($form->option_activate_value,'form_activate_date')==0)&&(strcmp($form->option_close_value,'form_close_date')==0)){
      $friendlytime_from=date("d/m/Y",$form->activate_time) . " " . elgg_echo("form:at") . " " . date("G:i",$form->activate_time);
      $friendlytime_to=date("d/m/Y",$form->close_time) . " " . elgg_echo("form:at") . " " . date("G:i",$form->close_time);
      $open_interval=elgg_echo('form:opened_from') . ": " . $friendlytime_from . " " . elgg_echo('form:to') . ": " . $friendlytime_to;
  
   } elseif (strcmp($form->option_activate_value,'form_activate_date')==0) {
       $friendlytime_from=date("d/m/Y",$form->activate_time) . " " . elgg_echo("form:at") . " " . date("G:i",$form->activate_time);
       $open_interval=elgg_echo('form:opened_from') . ": " . $friendlytime_from; 
   } elseif (strcmp($form->option_close_value,'form_close_date')==0) {
       $friendlytime_to=date("d/m/Y",$form->close_time) . " " . elgg_echo("form:at") . " " . date("G:i",$form->close_time);
       $open_interval=elgg_echo('form:opened_to') . ": " . $friendlytime_to; 
   } else {
      $open_interval = elgg_echo('form:is_opened');
   }
} else {
   $open_interval = elgg_echo('form:is_closed');
}

///////////////////////////////////////////////////////////////////
//Links to actions
if (($form->canEdit())&&($operator)) {
   if ($created) {
      if ($opened) {
         //Close
         $url_close = elgg_add_action_tokens_to_url(elgg_get_site_url() . "action/form/close?edit=no&formpost=" . $formpost);
         $word_close = elgg_echo("form:close_in_listing");
         $link_open_close = "<a href=\"{$url_close}\">{$word_close}</a>";
      } else {
         //Open
         $url_open = elgg_add_action_tokens_to_url(elgg_get_site_url() . "action/form/open?formpost=" . $formpost);
         $word_open = elgg_echo("form:open_in_listing");
         $link_open_close = "<a href=\"{$url_open}\">{$word_open}</a>";
      }  
      //if ($form->visibility){
      //   $word_visibility = elgg_echo("form:enable_visibility");
      //} else {
      //   $word_visibility = elgg_echo("form:disable_visibility");
      //}
      //$url_visibility = elgg_add_action_tokens_to_url(elgg_get_site_url() . "action/form/change_visibility?formpost=" . $formpost);
      //$link_visibility = "<a href=\"{$url_visibility}\">{$word_visibility}</a>";
   } else {
      $url_publish = elgg_add_action_tokens_to_url(elgg_get_site_url() . "action/form/publish?formpost=" . $formpost);
      $word_publish = elgg_echo("form:publish");
      $link_publish = "<a href=\"{$url_publish}\">{$word_publish}</a>";
   }
}

if ($operator) {
   //Copy
   $user_groups = array();
   $user_groups = elgg_get_entities(array('type' => 'group', 'subtype' => 0, 'limit' => false, 'owner_guid' => $user_guid));
   $options = array('relationship' => 'group_admin', 'relationship_guid' => $user_guid,'inverse_relationship' => false, 'type' => 'group');
   $other_user_groups = elgg_get_entities_from_relationship($options);
   if ($user_groups) {
      $user_groups = array_merge($user_groups,$other_user_groups);
   } else {
      $user_groups = $other_user_groups;
   }
   $select = "<select name=\"container_guid\">";
   foreach ($user_groups as $one_user_group){
      $one_user_group_guid = $one_user_group->getGUID();
      $one_user_group_name = $one_user_group->name;
      $select .= "<option value=\"$one_user_group_guid\">$one_user_group_name </option>"; 
   }
   $select .= "</select>";
   $body_form = "<br>" . elgg_echo("form:copy_to") . ": ";
   $body_form .= $select . "<br><br>";
   $body_form .= elgg_view('input/hidden', array('name' => 'formpost', 'value' => $formpost));
   $body_form .= elgg_view('input/submit', array('value' => elgg_echo("form:copy"), 'name' => 'submit'));
   $show_body_form = elgg_view('input/form', array('action' => elgg_get_site_url() . "action/form/copy", 'body' => $body_form, 'enctype' => 'multipart/form-data'));
   $show_body_form .= elgg_view('input/securitytoken');
}

if (($operator)&&(empty($vars['this_user_guid']))) { //||((!$operator)&&(empty($vars['this_user_guid']))&&(!$opened)&&($form->visibility))) {
   if (!$form->subgroups){
      $members = $group->getMembers(array('limit'=>false));
   } else {
      $members=elgg_get_entities(array('type_subtype_pairs' => array('group' => 'lbr_subgroup'),'limit' => 0,'container_guids' => $group_guid));
   }
   $i=0;
   $membersarray=array();
   foreach ($members as $member){
      $member_guid=$member->getGUID();
      if (($member_guid!=$owner_guid)&&($group_owner_guid!=$member_guid)&&(!check_entity_relationship($member_guid,'group_admin',$group_guid))){
         if (!$form->subgroups){
	    $options = array('relationship' => 'form_answer', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_answer', 'limit' => 0, 'owner_guid' => $member_guid);
         } else {
	    $options = array('relationship' => 'form_answer', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_answer', 'container_guid' => $member_guid, 'limit' => 0);
	 }
	 $user_responses=elgg_get_entities_from_relationship($options);
      	 if (!empty($user_responses)){	 
            $membersarray[$i] = $member;
	    $i=$i+1;
      	 }
      }
   }

   $num_responses = $i;
   if ($num_responses != 1) {
      $label_num_responses = elgg_echo('form:num_responses');
   } else {
      $label_num_responses = elgg_echo('form:num_response');
   }
}

$num_comments = $form->countComments();
if ($num_comments != 1) {
   $label_num_comments = elgg_echo('form:num_comments');
} else {
   $label_num_comments = elgg_echo('form:num_comment');
}

if ($full) {
   if (!form_check_status($form)) {
      $title="<div class=\"form_title\"><a class=\"closed_title_form\" href=\"{$form->getURL()}\">{$form->title}</a></div>";
   } else {
      $title="<div class=\"form_title\"><a class=\"opened_title_form\" href=\"{$form->getURL()}\">{$form->title}</a></div>";
   }
   $params = array('entity' => $form,'title' => $title,'metadata' => $metadata,'subtitle' => $subtitle,'tags' => $tags);
   $params = $params + $vars;
   $summary = elgg_view('object/elements/summary', $params);
   $body = "";
      
   $body .= $open_interval;
   
   //Links to actions
   if (($form->canEdit())&&($operator)) {
      if ($created) {
         $body .= "<br>" . $link_open_close; // . " " . $link_visibility;
      } else {
         $body .= "<br>" . $link_publish;
      }
   }

   if ($operator) {
      $body .= $show_body_form;
   }

   $body .= "<br><br>";

   //////////////////////////////////////////////////////////
	 
   if (($operator)&&(empty($vars['this_user_guid']))) { //||((!$operator)&&(empty($vars['this_user_guid']))&&(!$opened)&&($form->visibility))) {
      $body .= elgg_view('form/show_answers', array('entity' => $form, 'offset' => $vars['offset'], 'membersarray' => $membersarray, 'num_responses' => $num_responses,'operator'=>$operator));
   } else {   
      if (($opened)&&(!$operator)){
         $body .= elgg_view('forms/form/answer', array('entity' => $form, 'user_guid' => $user_guid));
      } else {
         if (!empty($vars['this_user_guid'])) {
            $user_guid = $vars['this_user_guid'];
         } else {
            if ($form->subgroups){
	       $container_guid  = $form->container_guid;
               $container = get_entity($container_guid);
               $user_subgroup = elgg_get_entities_from_relationship(array('type_subtype_pairs' => array('group' => 'lbr_subgroup'),'container_guids' => $container_guid,'relationship' => 'member','inverse_relationship' => false,'relationship_guid' => $user_guid));
               $user_guid=$user_subgroup[0]->getGUID();
            }
         }
	 if (strcmp($user_guid,"none")==0)
            $body .= elgg_view('forms/form/answer', array('entity' => $form, 'user_guid' => $user_guid));
         else
	    $body .= elgg_view('forms/form/show_answer', array('entity' => $form, 'user_guid' => $user_guid));
      }
   } 	    
   echo elgg_view('object/elements/full', array('summary' => $summary,'icon' => $owner_icon,'body' => $body));

} else {

   if (!form_check_status($form)) {
      $title="<div class=\"form_title\"><a class=\"closed_title_form\" href=\"{$form->getURL()}\">{$form->title}</a></div>";
   } else {
      $title="<div class=\"form_title\"><a class=\"opened_title_form\" href=\"{$form->getURL()}\">{$form->title}</a></div>";
   }
   $params = array('entity' => $form,'title' => $title,'metadata' => $metadata,'subtitle' => $subtitle,'tags' => $tags);
   $params = $params + $vars;
   $list_body = elgg_view('object/elements/summary', $params);
  
   $body = "";

   ///////////////////////////////////////////////////////////////
   //Form information
   $body .= $open_interval . "<br>";
   
   if ($operator){ 
      $body .= $num_responses . " " . $label_num_responses . ", ";
   }
   
   $body .= $num_comments . " " . $label_num_comments;

   if (!$operator){
      if (strcmp($user_type,"finished")==0){
         $body .= "<br>" . elgg_echo('form:finished');
      } 
   }

   //Links to actions
   if (($form->canEdit())&&($operator)) {
      if ($created){
         $body .= "<br>" . $link_open_close; // . " " . $link_visibility;
      } else {
         $body .= "<br>" . $link_publish;
      }
   }

   $list_body .= $body;

   echo elgg_view_image_block($owner_icon, $list_body);
}

?>
