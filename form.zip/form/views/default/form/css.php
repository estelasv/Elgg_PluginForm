.singleview {
	margin-top:10px;
}
.form-compressed-date {
        width: 150px !important;
        margin-right: 10px;
}
.form_options {
	text-align:right;
	float:right;
	margin:5px 5px 5px 50px;
}
.form_questions_list_table td{
	padding:5px;
}
.form_questions_list_table {
	width: 100%;
	border:1px solid #4690D6;
}
.form_questions_field_list_table_head td{
	background:#4690D6;
}
.form_dates_table td {
        width: 365px;
        padding: 10px 10px 10px 10px;
}
.form_frame {
        background-color: #d4d5ff;
        margin: 0 0 0 0;
        border: 1px solid #aaaaaa;
        padding: 10px 0 10px 0;
}
.form_frame_blue {
        background-color: #b3d3f3;
        margin: 0 0 0 0;
        border: 1px solid #aaaaaa;
        padding: 10px 0 10px 0;
}
.form_frame_green {
        background-color: #b7f7b7;
        margin: 0 0 0 0;
        border: 1px solid #aaaaaa;
        padding: 10px 0 10px 0;
}
.form_frame_red {
        background-color: #fab6b6;
        margin: 0 0 0 0;
        border: 1px solid #aaaaaa;
        padding: 10px 0 10px 0;
}
.form_question_frame {
        margin: 0 0 0 0;
        border: 1px solid #aaaaaa;
        padding: 5px 5px 5px 5px;
}
.form_title {
        font-size:14px;
        font-weight:bold;
}
.opened_title_form {
        color: green;
}
.closed_title_form {
        color: red;
}
