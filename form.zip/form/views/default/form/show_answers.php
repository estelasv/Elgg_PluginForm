<?php

$form=$vars['entity'];
$formpost=$form->getGUID();
$offset=$vars['offset'];
$operator=$vars['operator'];
$membersarray = $vars['membersarray'];
if (!empty($membersarray))
   $count = count($membersarray);
else
   $count = 0;
$limit=10;
$this_limit = $offset+$limit;

$form_body = "";

$wwwroot = elgg_get_config('wwwroot');
$img_template = '<img border="0" width="20" height="20" alt="%s" title=
"%s" src="'.$wwwroot.'mod/form/graphics/%s" />';

if ($operator) {
   $url_view_form=elgg_add_action_tokens_to_url(elgg_get_site_url() . "form/view/$formpost/?this_user_guid=none");
   $text_view_form = elgg_echo('form:view_form');
   $link_view_form="<a href=\"{$url_view_form}\">{$text_view_form}</a>";
   $form_body .= $link_view_form;
   $form_body .= "<br>";
}

if (($count>0)&&($operator)){

   //Export to csv
   //$url_export_csv=elgg_add_action_tokens_to_url(elgg_get_site_url() . "mod/form/export_csv.php?formpost=$formpost");
   //$text_export_csv=elgg_echo("form:export_csv");
   //$img_export_csv = sprintf($img_template,$text_export_csv,$text_export_csv,"csv_icon.jpeg");
   //$link_export_csv="<a href=\"{$url_export_csv}\">{$img_export_csv}</a>";
   //$form_body .= $link_export_csv;

   $options = array('relationship' => 'form_question', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_question','limit'=>0);
   $questions=elgg_get_entities_from_relationship($options);
  
   $show_zip=true;
   if ($show_zip) {

      //Create zips
      $url_zip=elgg_add_action_tokens_to_url(elgg_get_site_url() . "action/form/zip_all?formpost=$formpost");
      $text_zip=elgg_echo("form:zips");
      $img_zip = sprintf($img_template,$text_zip,$text_zip,"zip_icon_grey.jpeg");
      $link_zip="<a href=\"{$url_zip}\">{$img_zip}</a>";
      $form_body .= $link_zip;

      //Get zips
      $url_get_zip=elgg_add_action_tokens_to_url(elgg_get_site_url() . "action/form/get_zips?formpost=$formpost");
      $text_get_zip=elgg_echo("form:get_zips");
      $img_get_zip = sprintf($img_template,$text_get_zip,$text_get_zip,"zip_icon.jpeg");
      $link_get_zip="<a href=\"{$url_get_zip}\">{$img_get_zip}</a>";
      $form_body .= $link_get_zip;
   }

   $form_body .= "<br>";

}

//General comments
$num_comments =  $form->countComments();
if ($num_comments>0)
   $form_general_comments_label = elgg_echo('form:general_comments') . " (" . $num_comments . ")";
else
   $form_general_comments_label = elgg_echo('form:general_comments');
$form_body .= "<div class=\"contentWrapper\">";
$form_body .= "<div class=\"form_frame\">";
$form_body .= "<p align=\"left\"><a onclick=\"form_show_general_comments();\" style=\"cursor:hand;\">$form_general_comments_label</a></p>";
$form_body .= "<div id=\"commentsDiv\" style=\"display:none;\">";
$form_body .= elgg_view_comments($form);
$form_body .= "</div>";
$form_body .= "</div>";
$form_body .= "</div>";

////////////////////////////////////////////////////////////////////////////
//Responses

$form_body .= "<div class=\"contentWrapper\">";
$form_body .= "<div class=\"form_frame_green\">";

if ($count>0){

   $form_body .= elgg_echo('form:responses') . " (" . $count . ")" . "<br>";
   
   $i=0;

   foreach ($membersarray as $member){
      if (($i>=$offset)&&($i<$this_limit)){
         $member_guid=$member->getGUID();
         $url=elgg_add_action_tokens_to_url(elgg_get_site_url() . "form/view/$formpost/?this_user_guid=$member_guid&offset=$offset");
         $text_url = elgg_echo('form:response') . " " . elgg_echo('form:of') . " " . $member->name;

         $url_export_pdf=elgg_add_action_tokens_to_url(elgg_get_site_url() . "action/form/export_pdf?formpost=$formpost&user_guid=$member_guid");
         $text_export_pdf=elgg_echo("form:export_pdf");
         $img_export_pdf = sprintf($img_template,$text_export_pdf,$text_export_pdf,"pdf_icon.gif");

	 $show_this_zip=true;
	 if (($show_zip)&&($show_this_zip)) {
            $url_zip=elgg_add_action_tokens_to_url(elgg_get_site_url() . "action/form/zip?formpost=$formpost&user_guid=$member_guid");
            $text_zip=elgg_echo("form:get_zip");
            $img_zip = sprintf($img_template,$text_zip,$text_zip,"zip_icon.jpeg");
            $link_zip="<a href=\"{$url_zip}\">{$img_zip}</a>";
         }

         if (!$form->subgroups){
            $options = array('relationship' => 'form_answer', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_answer', 'order_by' => 'e.time_created desc', 'limit' => 0, 'owner_guid' => $member_guid);
         } else {
            $options = array('relationship' => 'form_answer', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_answer', 'order_by' => 'e.time_created desc', 'limit' => 0, 'container_guid' => $member_guid);
         }
         $user_responses=elgg_get_entities_from_relationship($options);
         if (!empty($user_responses)){
            $link="<a href=\"{$url}\">{$text_url}</a><br>";
	    $link.="<a href=\"{$url_export_pdf}\">{$img_export_pdf}</a>";
	    if (($show_zip)&&($show_this_zip))
               $link.="<a href=\"{$url_zip}\">{$img_zip}</a>";

         } else {
            $link="";
         }
      
         $icon = elgg_view_entity_icon($member,'small');
	 $info = $link . "<br>";
	 $form_body .= elgg_view_image_block($icon,$info);
      }
      $i=$i+1;
   }
   $form_body .= elgg_view("navigation/pagination",array('count'=>$count,'offset'=>$offset,'limit'=>$limit));

} else {
   $form_body .= elgg_echo('form:responses') . "<br>";
   $form_body .= elgg_echo('form:not_responses');
}
$form_body .= "</div>";
$form_body .= "</div>";

echo elgg_echo($form_body);

?>

<script type="text/javascript">
   function form_show_general_comments(){
      var commentsDiv = document.getElementById('commentsDiv');
      if (commentsDiv.style.display == 'none'){
         commentsDiv.style.display = 'block';
      } else {       
         commentsDiv.style.display = 'none';
      }
   }    
</script>
