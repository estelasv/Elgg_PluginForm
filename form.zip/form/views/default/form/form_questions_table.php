<?php

$form = $vars['entity'];
$formpost = $form->getGUID();

$options = array('relationship' => 'form_question', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_question','limit'=>0,'order_by_metadata' => array('name' => 'index', 'direction' => 'asc','as'=>'integer'));
$questions = elgg_get_entities_from_relationship($options);

if (empty($questions)) {
   $num_questions = 0;
} else {
   $num_questions = count($questions);
}
      
$edit_msg = elgg_echo('form:edit_question');
$delete_msg = elgg_echo('form:delete_question');
$delete_confirm_msg = elgg_echo('form:delete_question_confirm');
$moveup_msg = elgg_echo('form:up');
$movedown_msg = elgg_echo('form:down');
$movetop_msg = elgg_echo('form:top');
$movebottom_msg = elgg_echo('form:bottom');

$wwwroot = elgg_get_config('wwwroot');	
$img_template = '<img border="0" width="16" height="16" alt="%s" title="%s" src="'.$wwwroot.'mod/form/graphics/%s" />';
$edit_img = sprintf($img_template,$edit_msg,$edit_msg,"edit_question.jpeg");
$delete_img = sprintf($img_template,$delete_msg,$delete_msg,"delete.gif");
	
$question_txt = elgg_echo('form:questions');
$edit_txt = elgg_echo('form:edit_question');
$delete_txt = elgg_echo('form:delete_question');
$up_txt = elgg_echo('form:up');
$down_txt = elgg_echo('form:down');
$top_txt = elgg_echo('form:top');
$bottom_txt = elgg_echo('form:bottom');
	

	$body .= <<<EOF
			<SCRIPT>
				function call_mouse_over_function(object){
					$(object).css("background","#E3F1FF");
				}
				function call_mouse_out_function(object){
					$(object).css("background","");
				}
			</SCRIPT>
			<table class="form_questions_list_table">
				
EOF;
	
foreach($questions as $question){
        $index=$question->index;
    	$question_guid = $question->getGUID();
    	$class = $class == "form_questions_list_table_odd" ? "form_questions_list_table_even" : "form_questions_list_table_odd";
        $moveup_img = sprintf($img_template,$moveup_msg,$moveup_msg,"up.png");
	$movedown_img = sprintf($img_template,$movedown_msg,$movedown_msg,"down.png");
	$movetop_img = sprintf($img_template,$movetop_msg,$movetop_msg,"top.png");
	$movebottom_img = sprintf($img_template,$movebottom_msg,$movebottom_msg,"bottom.png");
	$up_script = "";
    	$top_script = "";
    	$down_script = "";
    	$bottom_script = "";
    $url = elgg_get_site_url();
	$url_delete=elgg_add_action_tokens_to_url($url . "action/form/delete_question?formpost=" . $formpost . "&index=" . $index);
	$url_edit = elgg_add_action_tokens_to_url($url . "form/edit_question/" . $formpost . "/" . $index);
	$url_up = elgg_add_action_tokens_to_url($url . "action/form/move_question?formpost=" . $formpost . "&ac=up" . "&index=" . $index);
	$url_down = elgg_add_action_tokens_to_url($url . "action/form/move_question?formpost=" . $formpost . "&ac=down" . "&index=" . $index);
	$url_top = elgg_add_action_tokens_to_url($url . "action/form/move_question?formpost=" . $formpost . "&ac=top" . "&index=" . $index);
	$url_bottom = elgg_add_action_tokens_to_url($url . "action/form/move_question?formpost=" . $formpost . "&ac=bottom" . "&index=" . $index);

	$text_question = elgg_get_excerpt($question->question,45);
	
    	if($num_questions == 1){
    		$up_script = 'Onclick="javascript:return false;"';
        	$top_script = 'Onclick="javascript:return false;"';
        	$down_script = 'Onclick="javascript:return false;"';
        	$bottom_script = 'Onclick="javascript:return false;"';
        	$moveup_img = sprintf($img_template,$moveup_msg,$moveup_msg,"up_dis.png");
        	$movetop_img = sprintf($img_template,$movetop_msg,$movetop_msg,"top_dis.png");
        	$movedown_img = sprintf($img_template,$movedown_msg,$movedown_msg,"down_dis.png");
        	$movebottom_img = sprintf($img_template,$movebottom_msg,$movebottom_msg,"bottom_dis.png");
        	
	}elseif($num_questions == 2){
        	$top_script = 'Onclick="javascript:return false;"';
        	$bottom_script = 'Onclick="javascript:return false;"';
        	$movetop_img = sprintf($img_template,$movetop_msg,$movetop_msg,"top_dis.png");
        	$movebottom_img = sprintf($img_template,$movebottom_msg,$movebottom_msg,"bottom_dis.png");
		if ($question->index==0){
		   $up_script = 'Onclick="javascript:return false;"';
		   $moveup_img = sprintf($img_template,$moveup_msg,$moveup_msg,"up_dis.png");
		} else {
		   $up_script = "";
		}
		if ($question->index+1 == $num_questions){
		   $down_script = 'Onclick="javascript:return false;"';
		   $movedown_img = sprintf($img_template,$movedown_msg,$movedown_msg,"down_dis.png");
		} else {
		   $down_script = "";
		}
    	}elseif($question->index == 0){
        	$up_script = 'Onclick="javascript:return false;"';
        	$top_script = 'Onclick="javascript:return false;"';
        	$down_script = "";
        	$bottom_script = "";
        	$moveup_img = sprintf($img_template,$moveup_msg,$moveup_msg,"up_dis.png");
        	$movetop_img = sprintf($img_template,$movetop_msg,$movetop_msg,"top_dis.png");
        }elseif ($question->index+1 == $num_questions){
        	$up_script = "";
        	$top_script = "";
        	$down_script = 'Onclick="javascript:return false;"';
        	$bottom_script = 'Onclick="javascript:return false;"';
        	$movedown_img = sprintf($img_template,$movedown_msg,$movedown_msg,"down_dis.png");
        	$movebottom_img = sprintf($img_template,$movebottom_msg,$movebottom_msg,"bottom_dis.png");
        }
        
        $field_template = <<<END
        	<tr class="%s" onmouseover="call_mouse_over_function(this)" onmouseout="call_mouse_out_function(this)">
				<td style="width:345px;">%s</td>
				<td style="text-align:center"><a href="{$url_edit}">$edit_img</a></td>
				<td style="text-align:center"><a href="{$url_up}" %s>$moveup_img</a></td>
				<td style="text-align:center"><a href="{$url_down}" %s>$movedown_img</a></td>
				<td style="text-align:center"><a href="{$url_top}" %s >$movetop_img</a></td>
				<td style="text-align:center"><a href="{$url_bottom} %s">$movebottom_img</a></td>
				<td style="text-align:center"><a href="{$url_export_question}">$export_question_img</a></td>
				<td style="text-align:center"><a onclick="return confirm('$delete_confirm_msg')" href="{$url_delete}">$delete_img</a></td>
			</tr>
END;
        
$body .= sprintf($field_template,$class,$text_question,$up_script,$down_script,$top_script,$bottom_script);
}
    
$body .= "</table>";
echo $body;
?>
