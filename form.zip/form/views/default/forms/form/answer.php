<div class="contentWrapper">

<?php
	 
if (isset($vars['entity'])){
   
   $formpost=$vars['entity']->getGUID();
   $form=$vars['entity'];
   $action = "form/answer";
   
   $description = $vars['entity']->description;
   
   $user_guid = $vars['user_guid'];
   $user = get_entity($user_guid);
   $container_guid  = $form->container_guid;
   $container = get_entity($container_guid);

   //Answers

   if (strcmp($user_guid,"none")!=0) {
      if ($form->subgroups){
         $user_subgroup = elgg_get_entities_from_relationship(array('type_subtype_pairs' => array('group' => 'lbr_subgroup'),'container_guids' => $container_guid,'relationship' => 'member','inverse_relationship' => false,'relationship_guid' => $user_guid));
         $user_subgroup_guid=$user_subgroup[0]->getGUID();
      }
   
      if (!$form->subgroups){
         $options = array('relationship' => 'form_answer', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_answer', 'order_by' => 'e.time_created desc', 'limit' => 0, 'owner_guid' => $user_guid);
      } else {
         $options = array('relationship' => 'form_answer', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_answer', 'order_by' => 'e.time_created desc', 'limit' => 0, 'container_guid' => $user_subgroup_guid);
      }
      $user_responses=elgg_get_entities_from_relationship($options);
      if (!empty($user_responses)){
         $user_response=$user_responses[0];
         $user_response_content_array = explode(Chr(27),$user_response->content);
         $user_response_content_array = array_map('trim', $user_response_content_array);
      } else {
         $user_response="";
      }
   } else {
      $user_response = "";
   }

   // Previous information
   ?>
   <div class="form_frame">
      <?php 
      if (strcmp($description,"")!=0){
         ?>
         <p>
         <b><?php echo elgg_echo('form:form_description_label'); ?></b>
         </p>
         <div class="form_question_frame">
            <?php echo elgg_view('output/longtext', array('value' => $description)); ?>
         </div>
         <br>
         <?php
      }

      //General comments
      $num_comments =  $form->countComments();
      if ($num_comments>0)
         $form_general_comments_label = elgg_echo('form:general_comments') . " (" . $num_comments . ")";
      else
         $form_general_comments_label = elgg_echo('form:general_comments');
      ?>
      <p align="left"><a onclick="form_show_general_comments();" style="cursor:hand;"><?php echo $form_general_comments_label; ?></a></p>
      <div id="commentsDiv" style="display:none;">
         <?php echo elgg_view_comments($form);?>
      </div>
   </div>
   <br>
   <?php
   if (!empty($user_response)) {
      ?>
      <div class="form_frame_red">
         <?php
         $time_created = $user_response->time_created;
         $time_updated = $user_response->answer_time;
         $friendly_date_created = date('Y/m/d',$time_created);
         $friendly_time_created = date('G:i:s',$time_created);
         echo elgg_echo('form:response_created') . " " . $friendly_date_created . " " . elgg_echo('form:at') . " " . $friendly_time_created; 

         if (($time_updated)&&($time_created != $time_updated)) {
            $friendly_date_updated = date('Y/m/d',$time_updated);
            $friendly_time_updated = date('G:i:s',$time_updated);
            echo "<br>";
            echo elgg_echo('form:response_updated') . " " . $friendly_date_updated . " " . elgg_echo('form:at') . " " . $friendly_time_updated; 
         }
	 echo "<br>";
    $wwwroot = elgg_get_config('wwwroot');
	 $img_template = '<img border="0" width="16" height="16" alt="%s" title=
"%s" src="'.$wwwroot.'mod/form/graphics/%s" />';
         if ($form->subgroups){
	    $url_export_pdf=elgg_add_action_tokens_to_url(elgg_get_site_url() . "action/form/export_pdf?formpost=$formpost&user_guid=$user_subgroup_guid");
         } else {
	    $url_export_pdf=elgg_add_action_tokens_to_url(elgg_get_site_url() . "action/form/export_pdf?formpost=$formpost&user_guid=$user_guid");
	 }
         $text_export_pdf=elgg_echo("form:export_pdf");
         $img_export_pdf = sprintf($img_template,$text_export_pdf,$text_export_pdf,"pdf_icon.gif");
         echo "<a href=\"{$url_export_pdf}\">{$img_export_pdf}</a> ";
	 if ($form->subgroups){
            $url_delete_answer=elgg_add_action_tokens_to_url(elgg_get_site_url() . "action/form/delete_answer?formpost=$formpost&user_guid=$user_subgroup_guid");
         } else {
            $url_delete_answer=elgg_add_action_tokens_to_url(elgg_get_site_url() . "action/form/delete_answer?formpost=$formpost&user_guid=$user_guid");
         }
         $text_delete_answer=elgg_echo("delete");
	 $confirm_delete_msg = elgg_echo('form:delete_answer_confirm');
         $img_delete_answer = sprintf($img_template,$text_delete_answer,$text_delete_answer,"delete.gif");
         echo "<a  onclick=\"return confirm('$confirm_delete_msg')\" href=\"{$url_delete_answer}\">{$img_delete_answer}</a>";

         //Comments
         $num_comments =  $user_response->countComments();
         if ($num_comments>0)
            $comments_label = elgg_echo('form:comments_label') . " (" . $num_comments . ")";
         else
            $comments_label = elgg_echo('form:comments_label');
         ?>
         <p align="left"><a onclick="form_show_comments();" style="cursor:hand;"><?php echo $comments_label; ?></a></p>
         <div id="comments_responseDiv" style="display:none;">
            <?php echo elgg_view_comments($user_response);?>
         </div>
     
      </div>
      <br>
      <?php
   }
   
   //Questions
   $options = array('relationship' => 'form_question', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_question','limit'=>0);
   $questions=elgg_get_entities_from_relationship($options);
   if (empty($questions)) {
      $num_questions=0;
   } else {
      $num_questions=count($questions);
   }

   //Form
   ?>
   <form action="<?php echo elgg_get_site_url()."action/".$action?>" name="answer_form" enctype="multipart/form-data" method="post">

   <?php 
   echo elgg_view('input/securitytoken'); 

   //Each question
   $index=0;
   while ($index<$num_questions) {
   
      $options = array('relationship' => 'form_question', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_question','metadata_name_value_pairs' => array('name' => 'index', 'value' => $index));
      $this_question=elgg_get_entities_from_relationship($options);
      $one_question=$this_question[0];

      $question_guid=$one_question->getGUID();
      $question=$one_question->question;
      $obligatory_response=$one_question->obligatory_response;

      $question_text = "<div class=\"form_question_frame\">";
      $question_text .= elgg_view('output/text', array('value' => $question));
      $question_text .= "</div>";

      $question_body="";
      if (strcmp($one_question->question_html,"")!=0){
         $question_body .= "<p>" . "<b>" . elgg_echo('form:question_simple_read') . "</b>" . "</p>";
         $question_body .= "<div class=\"form_question_frame\">";
         $question_body .= elgg_view('output/longtext', array('value' => $one_question->question_html));
         $question_body .= "</div>";
      }
 
      $response_type=$one_question->response_type;
      if ((strcmp($response_type,"radiobutton")==0)||(strcmp($response_type,"checkbox")==0)){ 
         $responses_alignment=$one_question->responses_alignment;
         $responses=$one_question->responses;
      } else {
         if (strcmp($response_type,"grid")==0){ 
            $responses_rows=$one_question->responses_rows;
            $responses_columns=$one_question->responses_columns;
         }
      }

      //Response
   
      if (strcmp($response_type,"text")==0){ 
         $this_response_text = "";
	 $name_response='response_'.$index;
	 if (elgg_is_sticky_form('answer_form')) {
	    $this_response_text = elgg_get_sticky_value('answer_form',$name_response);
	 } else {
	    if (!empty($user_response))
               $this_response_text=$user_response_content_array[$index];
	 }
         if (strcmp($this_response_text,"not_response")==0)
            $this_response_text = "";
         $response_text = elgg_view('input/text', array('name' => $name_response,'value' => $this_response_text));
      } elseif (strcmp($response_type,"html")==0){
         $this_response_html = "";
	 $name_response="response_".$index;
	 if (elgg_is_sticky_form('answer_form')) {
	    $this_response_html = elgg_get_sticky_value('answer_form',$name_response);
	 } else {
            if (!empty($user_response))
               $this_response_html=$user_response_content_array[$index];
	 }
         if (strcmp($this_response_html,"not_response")==0)
            $this_response_html = "";
         $response_html = elgg_view('input/longtext', array('name' => $name_response,'value' => $this_response_html));
      } elseif ((strcmp($response_type,"radiobutton")==0)||(strcmp($response_type,"checkbox")==0)){ 
         $response_inputs = "";
         $responses_array = explode(Chr(26),$responses);
         $responses_array = array_map('trim', $responses_array);
         $responses_array2 = array();
         $this_responses="";
	 $name_response="response_".$index;
         if (strcmp($response_type,"checkbox")==0){
	    if (elgg_is_sticky_form('answer_form')) {
	       $this_responses = elgg_get_sticky_value('answer_form',$name_response);
	    } else { 
               if (!empty($user_response)) {	
                  $this_responses=explode(Chr(26),$user_response_content_array[$index]);
	          $this_responses = array_map('trim', $this_responses);
	       }
	    }
            // $responses_array must be associative array
            foreach ($responses_array as $key => $value) {
               $responses_array2[$value] = $value;
            }
            $response_inputs .= elgg_view('input/checkboxes', array('align'=>$responses_alignment,'name' => $name_response,'options' => $responses_array2, 'value' => $this_responses));
         } else {
	     if (elgg_is_sticky_form('answer_form')) {
	       $this_responses = elgg_get_sticky_value('answer_form',$name_response);
	    } else {
               if (!empty($user_response))
                  $this_responses = $user_response_content_array[$index];
            }
            // $responses_array must be associative array
            foreach ($responses_array as $key => $value) {
               $responses_array2[$value] = $value;
            }
	    $response_inputs .= elgg_view('input/radio', array('align'=>$responses_alignment,'name' => $name_response,'options' => $responses_array2, 'value' => $this_responses));
         }
      } elseif (strcmp($response_type,"grid")==0){
         $j=0;
         $grid_response_inputs = array();
         $responses_rows_array = explode(Chr(26),$responses_rows);
         $responses_rows_array = array_map('trim', $responses_rows_array);
         $responses_columns_array = explode(Chr(26),$responses_columns);
         $responses_columns_array = array_map('trim', $responses_columns_array);
         foreach ($responses_rows_array as $one_row){ 
            $grid_response_inputs[$j] = "";
            $name_response="grid_response_".$index."_".$j;
            $this_responses="";
	    if (elgg_is_sticky_form('answer_form')) {
	       $this_responses = elgg_get_sticky_value('answer_form',$name_response);
	    } else {
               if (!empty($user_response)) {
	          $this_responses = explode(Chr(26),$user_response_content_array[$index]);
	          $this_responses = array_map('trim', $this_responses);
		  $this_responses = $this_responses[$j];
	       }
	    }
	    $responses_columns_array2 = array();
            // $responses_array must be associative array
            foreach ($responses_columns_array as $key => $value) {
               $responses_columns_array2[$value] = $value;
            }
            $grid_response_inputs[$j] .= elgg_view('input/radio', array('name' => $name_response,'options' => $responses_columns_array2, 'value' => $this_responses));
            $j=$j+1;
         }
      } elseif (strcmp($response_type,"urls_files")==0){
         $name_response_names = 'response_urls_names_'.$index;
         $name_response = 'response_urls_'.$index; 
         $this_response_urls = "";
	 if (elgg_is_sticky_form('answer_form')) {
            $this_response_urls_names = elgg_get_sticky_value('answer_form',$name_response_names);
	    $this_response_urls = elgg_get_sticky_value('answer_form',$name_response);
	    $i=0;
            $this_response_comp_urls = array();
            foreach ($this_response_urls as $url){
               $this_response_comp_urls[$i] = $this_response_urls_names[$i] . Chr(24) . $this_response_urls[$i]; 
               $i=$i+1;
            }  
         } else { 
            if (!empty($user_response)) {
               if (strcmp($user_response_content_array[$index],"not_response")!=0) {
                  $this_response_comp_urls = explode(Chr(26),$user_response_content_array[$index]);
                  $this_response_comp_urls = array_map('trim',$this_response_comp_urls);
               }
            }
	 }
         $response_urls="";
         if ((count($this_response_comp_urls)>0)&&(strcmp($this_response_comp_urls[0],"")!=0)) {
	    $name_response_names = 'response_urls_names_'.$index.'[]';
            $name_response = 'response_urls_'.$index.'[]'; 
            $j=0;
            foreach ($this_response_comp_urls as $url) {
               $response_urls .= "<p class=\"clone_this_response_urls_" . $index . "\">";
               $comp_url = explode(Chr(24),$url);
               $comp_url = array_map('trim',$comp_url);
               $url_name = $comp_url[0];
               $url_value = $comp_url[1];
               $response_urls .= elgg_echo("form:response_url_name");
               $response_urls .= elgg_view("input/text", array('name' => $name_response_names,'value' => $url_name));
               $response_urls .= elgg_echo("form:response_url");
               $response_urls .= elgg_view("input/text", array('name' => $name_response,'value' => $url_value));
               if ($j>0){  
                  $response_urls .= "<!-- remove url --><a class=\"remove\" href=\"#\" onclick=\"$(this).parent().slideUp(function(){ $(this).remove() }); return false\">" . elgg_echo("delete") . "</a>";          
               }
               $response_urls .= "<br></p>";
               $j=$j+1;
            }
         } else {
            $response_urls .= "<p class=\"clone_this_response_urls_" . $index . "\">";
            $comp_url = explode(Chr(24),$this_response_comp_urls);
            $comp_url = array_map('trim',$comp_url);
            $url_name = $comp_url[0];
            $url_value = $comp_url[1];
            $response_urls .= elgg_echo("form:response_url_name");
            $response_urls .= elgg_view("input/text", array('name' => $name_response_names,'value' => $url_name));
            $response_urls .= elgg_echo("form:response_url");
            $response_urls .= elgg_view("input/text", array('name' => $name_response,'value' => $url_value));
            $response_urls .= "</p>";         
         }
         $response_urls .= "<!-- add link to add more urls which triggers a jquery clone function --><a href=\"#\" class=\"add\" rel=\".clone_this_response_urls_" . $index . "\">" . elgg_echo("form:add_url") . "</a>";
         $response_urls .= "<br /><br /></p>";
   
         if (!$form->subgroups) {
            $response_files = elgg_get_entities_from_relationship(array('relationship' => 'response_file_link','relationship_guid' => $question_guid,'inverse_relationship' => false,'type' => 'object','subtype' => 'form_response_file','owner_guid' => $user_guid,'limit'=>0));   
         } else {
            $response_files = elgg_get_entities_from_relationship(array('relationship' => 'response_file_link','relationship_guid' => $question_guid,'inverse_relationship' => false,'type' => 'object','subtype' => 'form_response_file','container_guid' => $user_subgroup_guid,'limit'=>0)); 
         }
         $name_response="upload_response_file_".$index."[]";
         $response_file = elgg_view("input/file",array( 'name' => $name_response, 'class' => 'multi'));
      }

      $num_question=$index+1;

      switch($response_type){
         case 'text':
            echo elgg_view("forms/form/answer_question",array('form'=>$form,'num_question'=>$num_question,'question_text'=>$question_text,'question_body'=>$question_body,'response_type'=>$response_type,'response_text'=>$response_text,'obligatory_response'=>$obligatory_response));
            break;
         case 'html':
            echo elgg_view("forms/form/answer_question",array('form'=>$form,'num_question'=>$num_question,'question_text'=>$question_text,'question_body'=>$question_body,'response_type'=>$response_type,'response_html'=>$response_html,'obligatory_response'=>$obligatory_response));
            break; 
         case 'radiobutton':
            echo elgg_view("forms/form/answer_question",array('form'=>$form,'num_question'=>$num_question,'question_text'=>$question_text,'question_body'=>$question_body,'response_type'=>$response_type,'response_inputs'=>$response_inputs,'obligatory_response'=>$obligatory_response));
            break;
         case 'checkbox':
            echo elgg_view("forms/form/answer_question",array('form'=>$form,'num_question'=>$num_question,'question_text'=>$question_text,'question_body'=>$question_body,'response_type'=>$response_type,'response_inputs'=>$response_inputs,'obligatory_response'=>$obligatory_response));
            break;
         case 'grid':
            echo elgg_view("forms/form/answer_question",array('form'=>$form,'num_question'=>$num_question,'question_text'=>$question_text,'question_body'=>$question_body,'response_type'=>$response_type,'responses_rows_array'=>$responses_rows_array,'grid_response_inputs'=>$grid_response_inputs,'obligatory_response'=>$obligatory_response));
            break;
	 case 'urls_files':
            echo elgg_view("forms/form/answer_question",array('form'=>$form,'num_question'=>$num_question,'question_text'=>$question_text,'question_body'=>$question_body,'response_type'=>$response_type,'response_urls'=>$response_urls,'response_file'=>$response_file,'response_files'=>$response_files,'obligatory_response'=>$obligatory_response));
         break;
      }   
      $index=$index+1;
   }

   elgg_clear_sticky_form('answer_form');

   if (strcmp($user_guid,"none")!=0) {
      //Submit 
      $form_answer = elgg_echo('form:answer');
      $submit_input_answer = elgg_view('input/submit', array('name' => 'submit', 'value' => $form_answer));
      $entity_hidden = elgg_view('input/hidden', array('name' => 'formpost', 'value' => $formpost));
      $entity_hidden .= elgg_view('input/hidden', array('name' => 'user_guid', 'value'=> $user_guid));

      ?>
      <p><?php echo $submit_input_answer . $entity_hidden; ?></p>      
   
      <?php
   }
   ?>

   <!-- add the add_response/delete_response functionality  -->
   <script type="text/javascript">
   // remove function for the jquery clone plugin
   $(function(){
      var removeLink = '<a class="remove" href="#" onclick="$(this).parent().slideUp(function(){ $(this).remove() }); return false"><?php echo elgg_echo("delete");?></a>';
      $('a.add').relCopy({ append: removeLink});
   });
   </script>

   </form>

<?php
}
?>
</div>

<script type="text/javascript">
   function form_show_general_comments(){
      var commentsDiv = document.getElementById('commentsDiv');
      if (commentsDiv.style.display == 'none'){
         commentsDiv.style.display = 'block';
      } else {       
         commentsDiv.style.display = 'none';
      }
   }    

   function form_show_comments(){
      var comments_responseDiv = document.getElementById('comments_responseDiv');
      if (comments_responseDiv.style.display == 'none'){
         comments_responseDiv.style.display = 'block';
      } else {       
         comments_responseDiv.style.display = 'none';
      }
   }    
</script>

<script type="text/javascript" src="<?php echo elgg_get_site_url(); ?>mod/form/lib/jquery.MultiFile.js"></script><!-- multi file jquery plugin -->
<script type="text/javascript" src="<?php echo elgg_get_site_url(); ?>mod/form/lib/reCopy.js"></script><!-- copy field jquery plugin -->
<script type="text/javascript" src="<?php echo elgg_get_site_url(); ?>mod/form/lib/js_functions.js"></script>

