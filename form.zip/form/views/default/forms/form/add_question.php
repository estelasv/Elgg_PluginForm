<div class="contentWrapper">

<?php

$action = "form/add_question";
$formpost = $vars['entity']->getGUID();

if (!elgg_is_sticky_form('add_question_form')) {
   $question = "";
   $obligatory_response = false;
   $question_html = "";
   $response_type="text";
   $responses = array();
   $responses_alignment = "horizontal";
   $responses_rows = array();
   $responses_columns = array();    
   $question_tags = "";    
} else {
   $question = elgg_get_sticky_value('add_question_form','question');
   $obligatory_response = elgg_get_sticky_value('add_question_form','obligatory_response');
   $question_html = elgg_get_sticky_value('add_question_form','question_html');
   $response_type = elgg_get_sticky_value('add_question_form','response_type');
   if ((strcmp($response_type,"radiobutton")==0)||(strcmp($response_type,"checkbox")==0)){
      $responses_alignment = elgg_get_sticky_value('add_question_form','responses_alignment');  
      $responses = elgg_get_sticky_value('add_question_form','responses');
   } else {
      if (strcmp($response_type,"grid")==0){
         $responses_rows = elgg_get_sticky_value('add_question_form','responses_rows');
	 $responses_columns = elgg_get_sticky_value('add_question_form','responses_columns');
      }
   }
   $question_tags =  elgg_get_sticky_value('add_question_form','question_tags');
} 
       
elgg_clear_sticky_form('add_question_form');

$options_response_type=array();
$options_response_type[0]=elgg_echo('form:response_type_text');
$options_response_type[1]=elgg_echo('form:response_type_html');
$options_response_type[2]=elgg_echo('form:response_type_radiobutton');
$options_response_type[3]=elgg_echo('form:response_type_checkbox');
$options_response_type[4]=elgg_echo('form:response_type_grid');
$options_response_type[5]=elgg_echo('form:response_type_urls_files');
$op_response_type=array();
$op_response_type[0]="text";
$op_response_type[1]="html";
$op_response_type[2]="radiobutton";
$op_response_type[3]="checkbox";
$op_response_type[4]="grid";
$op_response_type[5]="urls_files";
$checked_radio_response_type_0 = "";
$checked_radio_response_type_1 = "";
$checked_radio_response_type_2 = "";
$checked_radio_response_type_3 = "";
$checked_radio_response_type_4 = "";
$checked_radio_response_type_5 = "";

$options_responses_alignment=array();
$options_responses_alignment[0]=elgg_echo('form:responses_alignment_horizontal');
$options_responses_alignment[1]=elgg_echo('form:responses_alignment_vertical');
$op_responses_alignment=array();
$op_responses_alignment[0]="horizontal";
$op_responses_alignment[1]="vertical";
$checked_radio_responses_alignment_0 = "";
$checked_radio_responses_alignment_1 = "";

$style_display_response_type = "display:none";
$style_display_response_grid_type = "display:none";

switch($response_type){
   case 'text':
      $checked_radio_response_type_0 = "checked = \"checked\"";
      break;
   case 'html':
      $checked_radio_response_type_1 = "checked = \"checked\"";
      break;
   case 'radiobutton':
      $checked_radio_response_type_2 = "checked = \"checked\"";
      $style_display_response_type = "display:block";
      break;
   case 'checkbox':
      $checked_radio_response_type_3 = "checked = \"checked\"";
      $style_display_response_type = "display:block";
      break;
    case 'grid':
      $checked_radio_response_type_4 = "checked = \"checked\"";
      $style_display_response_grid_type = "display:block";
      break;
    case 'urls_files':
      $checked_radio_response_type_5 = "checked = \"checked\"";
      break;
}

switch($responses_alignment){
   case 'horizontal':
      $checked_radio_responses_alignment_0 = "checked = \"checked\"";
      break;
   case 'vertical':
      $checked_radio_responses_alignment_1 = "checked = \"checked\"";
      break;
}

$obligatory_response_label = elgg_echo('form:obligatory_response_label');
if ($obligatory_response){
   $selected_obligatory_response = "checked = \"checked\"";
} else {
   $selected_obligatory_response = "";
}

?>
<br/>

<form action="<?php echo elgg_get_site_url()."action/".$action?>" name="add_question_form" enctype="multipart/form-data" method="post">

<?php echo elgg_view('input/securitytoken'); ?>

<p>
<b><?php echo elgg_echo("form:question_label"); ?></b><br>
<?php
echo elgg_view("input/text", array('name' => 'question', 'value' => $question));
?>
</p>

<p>
<b>
<?php echo elgg_echo("form:form_question_simple"); ?>
</b>
<?php echo elgg_view("input/longtext" ,array('name' => 'question_html', 'value' => $question_html)); ?>
</p>
          
<p>
<b><?php echo elgg_echo("form:response_type_label"); ?></b><br />
<?php echo "<input type=\"radio\" name=\"response_type\" value=$op_response_type[0] $checked_radio_response_type_0 onclick=\"form_show_response_type(0)\">$options_response_type[0]";?><br> 
<?php echo "<input type=\"radio\" name=\"response_type\" value=$op_response_type[1] $checked_radio_response_type_1 onclick=\"form_show_response_type(1)\">$options_response_type[1]";?><br> 
<?php echo "<input type=\"radio\" name=\"response_type\" value=$op_response_type[2] $checked_radio_response_type_2 onclick=\"form_show_response_type(2)\">$options_response_type[2]";?><br> 
<?php echo "<input type=\"radio\" name=\"response_type\" value=$op_response_type[3] $checked_radio_response_type_3 onclick=\"form_show_response_type(3)\">$options_response_type[3]";?><br> 
<?php echo "<input type=\"radio\" name=\"response_type\" value=$op_response_type[4] $checked_radio_response_type_4 onclick=\"form_show_response_type(4)\">$options_response_type[4]";?><br> 
<?php echo "<input type=\"radio\" name=\"response_type\" value=$op_response_type[5] $checked_radio_response_type_5 onclick=\"form_show_response_type(5)\">$options_response_type[5]";?><br> 
</p>

<div id="resultsDiv_response_type" style="<?php echo $style_display_response_type;?>;">

   <p>
   <b><?php echo elgg_echo("form:responses_alignment_label"); ?></b><br />
   <?php echo "<input type=\"radio\" name=\"responses_alignment\" value=$op_responses_alignment[0] $checked_radio_responses_alignment_0>$options_responses_alignment[0]";?><br> 
    <?php echo "<input type=\"radio\" name=\"responses_alignment\" value=$op_responses_alignment[1] $checked_radio_responses_alignment_1>$options_responses_alignment[1]";?><br>
   </p>

   <p>
   <b><?php echo elgg_echo("form:possible_responses_label"); ?></b>
   </p>
        	
   <p>
   <?php
   if(count($responses) > 0) {
      $i=0;
      foreach ($responses as $response) {
         ?>
         <p class="clone">
         <?php
         echo elgg_view("input/text", array("name" => "responses[]","value" => $response)); 
         if ($i>0){	
            ?>							
            <!-- remove response -->
            <a class="remove" href="#" onclick="$(this).parent().slideUp(function(){ $(this).remove() }); return false"><?php echo elgg_echo("delete"); ?></a>   
	    <?php
         }
         ?>
         </p>   
         <?php 
         $i=$i+1;
      }
   } else {
      ?>
      <p class="clone">
      <?php
      echo elgg_view("input/text", array("name" => "responses[]","value" => $responses));
      ?>     
      </p>         
      <?php
   }
   ?>
   <!-- add link to add more responses which triggers a jquery clone function -->
   <a href="#" class="add" rel=".clone"><?php echo elgg_echo("form:add_response"); ?></a>
   <br /><br />
   </p>
   </div>

   <div id="resultsDiv_response_grid_type" style="<?php echo $style_display_response_grid_type;?>;">
      <p>
      <b><?php echo elgg_echo("form:rows_responses_label"); ?></b>
      </p>       	
      <p>
      <?php
      if(count($responses_rows) > 0) {
         $i=0;
         foreach ($responses_rows as $response) {
	    ?>
            <p class="clone_rows">
	    <?php
            echo elgg_view("input/text", array("name" => "responses_rows[]","value" => $response)); 
	    if ($i>0){	
	       ?>							
               <!-- remove row -->
               <a class="remove" href="#" onclick="$(this).parent().slideUp(function(){ $(this).remove() }); return false"><?php echo elgg_echo("delete"); ?></a>   
	       <?php
	    }
	 ?>
	 </p>   
         <?php 
	 $i=$i+1;
      }
   } else {
      ?>
      <p class="clone_rows">
      <?php
      echo elgg_view("input/text", array("name" => "responses_rows[]","value" => $responses_rows));
      ?>     
      </p>         
      <?php
   }
   ?>
   <!-- add link to add more rows which triggers a jquery clone function -->
   <a href="#" class="add" rel=".clone_rows"><?php echo elgg_echo("form:add_row"); ?></a>
   <br /><br />
   </p>

   <p>
   <b><?php echo elgg_echo("form:columns_responses_label"); ?></b>
   </p>       	
   <p>
   <?php
   if(count($responses_columns) > 0) {
      $i=0;
      foreach ($responses_columns as $response) {
         ?>
         <p class="clone_columns">
	 <?php
         echo elgg_view("input/text", array("name" => "responses_columns[]","value" => $response)); 
	 if ($i>0){	
	    ?>							
            <!-- remove column -->
            <a class="remove" href="#" onclick="$(this).parent().slideUp(function(){ $(this).remove() }); return false"><?php echo elgg_echo("delete"); ?></a>   
	    <?php
	 }
	 ?>
	 </p>   
         <?php 
	 $i=$i+1;
      }
   } else {
      ?>
      <p class="clone_columns">
      <?php
      echo elgg_view("input/text", array("name" => "responses_columns[]","value" => $responses_columns));
      ?>     
      </p>         
      <?php
   }
   ?>
   <!-- add link to add more columns which triggers a jquery clone function -->
   <a href="#" class="add" rel=".clone_columns"><?php echo elgg_echo("form:add_column"); ?></a>
   <br /><br />
   </p>
</div>

<p>
<b>
<?php echo "<input type = \"checkbox\" name = \"obligatory_response\" $selected_obligatory_response> $obligatory_response_label"; ?>
</b> 
</p><br>

<p>
<b><?php echo elgg_echo("tags"); ?></b>
<?php echo elgg_view("input/tags", array('name' => 'question_tags', 'value' => $question_tags)); ?>
</p><br>

<!-- add the add/delete functionality  -->
<script type="text/javascript">
// remove function for the jquery clone plugin
$(function(){
   var removeLink = '<a class="remove" href="#" onclick="$(this).parent().slideUp(function(){ $(this).remove() }); return false"><?php echo elgg_echo("delete");?></a>';
   $('a.add').relCopy({ append: removeLink});
});
</script>

<input type="hidden" name="formpost" value="<?php echo $formpost; ?>">

<?php 
$submit_input = elgg_view('input/submit', array('name' => 'submit', 'value' => elgg_echo("form:save")));
echo $submit_input
?>

</form>

<script language="javascript">
function form_show_response_type(response_type_id){
      var resultsDiv_response_type = document.getElementById('resultsDiv_response_type');   
      var resultsDiv_response_grid_type = document.getElementById('resultsDiv_response_grid_type');      
      
      
      if (resultsDiv_response_type.style.display == 'none'){
         if ((response_type_id == 2) || (response_type_id ==3)) 
            resultsDiv_response_type.style.display = 'block';
      } else {   
         if ((response_type_id != 2) && (response_type_id !=3))   
            resultsDiv_response_type.style.display = 'none';
      }

      if (resultsDiv_response_grid_type.style.display == 'none'){
         if (response_type_id == 4) 
            resultsDiv_response_grid_type.style.display = 'block';
      } else {   
         if (response_type_id != 4)
            resultsDiv_response_grid_type.style.display = 'none';
      }
}  

</script>

<script type="text/javascript" src="<?php echo elgg_get_site_url(); ?>mod/form/lib/jquery.MultiFile.js"></script><!-- multi file jquery plugin -->
<script type="text/javascript" src="<?php echo elgg_get_site_url(); ?>mod/form/lib/reCopy.js"></script><!-- copy field jquery plugin -->
<script type="text/javascript" src="<?php echo elgg_get_site_url(); ?>mod/form/lib/js_functions.js"></script>
</div>
