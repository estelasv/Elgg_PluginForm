<div class="contentWrapper">

<?php

$user_guid = elgg_get_logged_in_user_guid();
$action = "form/add";

if (!elgg_is_sticky_form('add_form')) {
   $title = "";
   $description = "";
   $confirm_correct_answer = false;
   $opendate = "";
   $closedate = "";
   $opentime = "00:00";
   $closetime = "00:00";
   $option_activate_value = 'form_activate_now';
   $option_close_value = 'form_not_close';
   //$visibility = true;
   $subgroups = false;
   $tags = "";
   $access_id = 0;
} else {
   $title = elgg_get_sticky_value('add_form','title');
   $description = elgg_get_sticky_value('add_form','description');
   $confirm_correct_answer = elgg_get_sticky_value('add_form','confirm_correct_answer');
   $opendate = elgg_get_sticky_value('add_form','opendate');
   $closedate = elgg_get_sticky_value('add_form','closedate');
   $opentime = elgg_get_sticky_value('add_form','opentime');
   $closetime = elgg_get_sticky_value('add_form','closetime');
   $option_activate_value = elgg_get_sticky_value('add_form','option_activate_value');
   $option_close_value = elgg_get_sticky_value('add_form','option_close_value');
   //$visibility = elgg_get_sticky_value('add_form','visibility');
   $subgroups = elgg_get_sticky_value('add_form','subgroups');
   $tags = elgg_get_sticky_value('add_form','formtags');
   $access_id = elgg_get_sticky_value('add_form','access_id');
}

elgg_clear_sticky_form('add_form');

$options_activate=array();
$options_activate[0]=elgg_echo('form:activate_now');
$options_activate[1]=elgg_echo('form:activate_date');
$op_activate=array();
$op_activate[0]='form_activate_now';
$op_activate[1]='form_activate_date';
if (strcmp($option_activate_value,$op_activate[0])==0){
   $checked_radio_activate_0 = "checked = \"checked\"";
   $checked_radio_activate_1 = "";
   $style_display_activate = "display:none";
} else {
   $checked_radio_activate_0 = "";
   $checked_radio_activate_1 = "checked = \"checked\"";
   $style_display_activate = "display:block";
}
$options_close=array();
$options_close[0]=elgg_echo('form:not_close');
$options_close[1]=elgg_echo('form:close_date');
$op_close=array();
$op_close[0]='form_not_close';
$op_close[1]='form_close_date';
if (strcmp($option_close_value,$op_close[0])==0){
   $checked_radio_close_0 = "checked = \"checked\"";
   $checked_radio_close_1 = "";
   $style_display_close = "display:none";
} else {
   $checked_radio_close_0 = "";
   $checked_radio_close_1 = "checked = \"checked\"";
   $style_display_close = "display:block";
}
$opendate_label = elgg_echo('form:opendate');
$closedate_label = elgg_echo('form:closedate');
$opentime_label = elgg_echo('form:opentime');
$closetime_label = elgg_echo('form:closetime');

$confirm_correct_answer_label = elgg_echo('form:confirm_correct_answer_label');
if ($confirm_correct_answer){
   $selected_confirm_correct_answer = "checked = \"checked\"";
} else {
   $selected_confirm_correct_answer = "";
}

//$visibility_label = elgg_echo('form:visibility_label');
//if ($visibility){
//   $selected_visibility = "checked = \"checked\"";
//} else {
//   $selected_visibility = "";
//}

$subgroups_label = elgg_echo('form:subgroups_label');
if ($subgroups){
   $selected_subgroups = "checked = \"checked\"";
} else {
   $selected_subgroups = "";
}

$tag_label = elgg_echo('tags');
$tag_input = elgg_view('input/tags', array('name' => 'formtags', 'value' => $tags));   
$access_label = elgg_echo('access');
$access_input = elgg_view('input/access', array('name' => 'access_id', 'value' => $access_id));

$form_add_question=elgg_echo('form:add_question');
$submit_input_add_question = elgg_view('input/submit', array('name' => 'submit', 'value' => $form_add_question));
        
?>

<form action="<?php echo elgg_get_site_url()."action/".$action?>" name="add_form" enctype="multipart/form-data" method="post">

<?php echo elgg_view('input/securitytoken'); ?>

<p>
<b><?php echo elgg_echo("form:title_label"); ?></b><br>
<?php echo elgg_view("input/text", array('name' => 'title', 'value' => $title)); ?>
</p>
<p>
<b><?php echo elgg_echo("form:description_label"); ?></b><br>
<?php echo elgg_view("input/longtext", array('name' => 'description', 'value' => $description)); ?>
</p>

<table class="form_dates_table">
<tr>
<td>
<p>
<b><?php echo elgg_echo('form:activate_label'); ?></b><br>
<?php echo "<input type=\"radio\" name=\"option_activate_value\" value=$op_activate[0] $checked_radio_activate_0 onChange=\"form_show_activate_time()\">$options_activate[0]";?><br> 
<?php echo "<input type=\"radio\" name=\"option_activate_value\" value=$op_activate[1] $checked_radio_activate_1 onChange=\"form_show_activate_time()\">$options_activate[1]";?><br> 
<div id="resultsDiv_activate" style="<?php echo $style_display_activate;?>;">
   <?php echo $opendate_label; ?><br> 
   <?php echo elgg_view('input/date',array('timestamp'=>TRUE, 'autocomplete'=>'off','class'=>'form-compressed-date','name'=>'opendate','value'=>$opendate)); ?>
   <?php echo "<br>" . $opentime_label; ?> <br> 
   <?php echo "<input type = \"text\" name = \"opentime\" value = $opentime>"; ?>  
</div>
</p><br>
</td>
<td>
<p>
<b><?php echo elgg_echo('form:close_label'); ?></b><br>
<?php echo "<input type=\"radio\" name=\"option_close_value\" value=$op_close[0] $checked_radio_close_0 onChange=\"form_show_close_time()\">$options_close[0]";?><br> 
<?php echo "<input type=\"radio\" name=\"option_close_value\" value=$op_close[1] $checked_radio_close_1 onChange=\"form_show_close_time()\">$options_close[1]";?><br>
<div id="resultsDiv_close" style="<?php echo $style_display_close;?>;">
   <?php echo $closedate_label; ?><br> 
   <?php echo elgg_view('input/date',array('timestamp'=>TRUE, 'autocomplete'=>'off','class'=>'form-compressed-date','name'=>'closedate','value'=>$closedate)); ?>
   <?php echo "<br>" . $closetime_label; ?> <br> 
   <?php echo "<input type = \"text\" name = \"closetime\" value = $closetime>"; ?>  
</div>
</p><br>
</td>
</tr>
</table>

<p>
<b>
<?php echo "<input type = \"checkbox\" name = \"confirm_correct_answer\" $selected_confirm_correct_answer> $confirm_correct_answer_label"; ?>
</b>         
</p><br>
<!--<p>
<b>
<?php //echo "<input type = \"checkbox\" name = \"visibility\" $selected_visibility> $visibility_label"; ?>
</b>         
</p><br>-->
<?php $container_guid = $vars['container_guid'];
   $container = get_entity($container_guid);
   if (!($container->getContainerEntity() instanceof ElggGroup)){ ?>
<p>
<b>
<?php echo "<input type = \"checkbox\" name = \"subgroups\" $selected_subgroups> $subgroups_label"; ?>
</b> 
</p><br>
<?php } ?>
<p>
<b><?php echo $tag_label; ?></b><br />
<?php echo $tag_input; ?>
</p><br>
<p>
<b><?php echo $access_label; ?></b><br />
<?php echo $access_input; ?>
</p>

<?php
echo "$submit_input_add_question";
?>

<input type="hidden" name="container_guid" value="<?php echo $vars['container_guid']; ?>">

</form>

<script language="javascript">
   function form_show_activate_time(){
      var resultsDiv_activate = document.getElementById('resultsDiv_activate');
      if (resultsDiv_activate.style.display == 'none'){
         resultsDiv_activate.style.display = 'block';
      } else {       
         resultsDiv_activate.style.display = 'none';
      }
   }   
   function form_show_close_time(){
      var resultsDiv_close = document.getElementById('resultsDiv_close');
      if (resultsDiv_close.style.display == 'none'){
            resultsDiv_close.style.display = 'block';
      } else {       
         resultsDiv_close.style.display = 'none';
      }
   }  
</script>

</div>


