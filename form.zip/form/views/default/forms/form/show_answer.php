<div class="contentWrapper">

<?php

if (isset($vars['entity'])) {
   $form=$vars['entity'];
   $formpost=$form->getGUID();
  
   $user_guid = $vars['user_guid'];
   $user = get_entity($user_guid);

   $container_guid  = $form->container_guid;
   $container = get_entity($container_guid);

   $my_guid=elgg_get_logged_in_user_guid();
   $my_user=get_entity($my_guid);
   $my_answer=false;

   $owner = $form->getOwnerEntity();
   $owner_guid = $owner->getGUID();
   $group_owner_guid = $container->owner_guid;
   $operator=false;
   if (($owner_guid==$my_guid)||($group_owner_guid==$my_guid)||(check_entity_relationship($my_guid,'group_admin',$container_guid))){
   $operator=true;
   }
   if (!$operator){
      if ($form->subgroups){
         $subgroups = elgg_get_entities_from_relationship(array('type_subtype_pairs' => array('group' => 'lbr_subgroup'),'container_guids' => $container_guid,'relationship' => 'member','inverse_relationship' => false,'relationship_guid' => $my_guid));
         $my_guid=$subgroups[0]->getGUID();
         if ($my_guid==$user_guid)
            $my_answer=true;
      } else {
         if ($my_guid==$user_guid) 
            $my_answer=true;
      }
   }
   if (!$my_answer)
      $icon = elgg_view_entity_icon($user,'small');
   
    //Answers
   if (!$form->subgroups){
      $options = array('relationship' => 'form_answer', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_answer', 'order_by' => 'e.time_created desc', 'limit' => 0, 'owner_guid' => $user_guid);
   } else {
      $options = array('relationship' => 'form_answer', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_answer', 'order_by' => 'e.time_created desc', 'limit' => 0, 'container_guid' => $user_guid);
   }
   $user_responses=elgg_get_entities_from_relationship($options);

   if (!empty($user_responses)) {
      $user_response=$user_responses[0];
      $user_response_content_array = explode(Chr(27),$user_response->content);
      $user_response_content_array = array_map('trim', $user_response_content_array);
   } else {
      $user_response="";
   }

   //Previous information

   $form_body = "";

   $form_body .= "<div class=\"form_frame\">";

   if (strcmp($form->description,"")!=0){
      $form_body .= "<p>" . "<b>" . elgg_echo('form:form_description_label') . "</b>" . "</p>";
      $form_body .= "<div class=\"form_question_frame\">";
      $form_body .= elgg_view('output/longtext', array('name' => 'description', 'value' => $form->description));
      $form_body .= "</div><br>";
   }

   //General comments
   $num_comments =  $form->countComments();
   if ($num_comments>0)
      $form_general_comments_label = elgg_echo('form:general_comments') . " (" . $num_comments . ")";
   else
      $form_general_comments_label = elgg_echo('form:general_comments');      
   $form_body .= "<p align=\"left\"><a onclick=\"form_show_general_comments();\" style=\"cursor:hand;\">$form_general_comments_label</a></p>";
   $form_body .= "<div id=\"commentsDiv\" style=\"display:none;\">";
   $form_body .= elgg_view_comments($form);
   $form_body .= "</div>";
   $form_body .= "<br>";

   $form_body .= "</div>";
   $form_body .= "<br>";

   if (!empty($user_response)) {
      $form_body .= "<div class=\"form_frame_red\">";
      if (!$my_answer) {
         $form_body .= $icon . " " . $user->name;
         $form_body .= "<br>";
      }
      $time_created = $user_response->time_created;
      $time_updated = $user_response->answer_time;
      $friendly_date_created = date('Y/m/d',$time_created);
      $friendly_time_created = date('G:i:s',$time_created);
      $form_body .= elgg_echo('form:response_created') . " " . $friendly_date_created . " " . elgg_echo('form:at') . " " . $friendly_time_created; 

      if (($time_updated)&&($time_created != $time_updated)) {
         $friendly_date_updated = date('Y/m/d',$time_updated);
         $friendly_time_updated = date('G:i:s',$time_updated);
         $form_body .= "<br>";
         $form_body .= elgg_echo('form:response_updated') . " " . $friendly_date_updated . " " . elgg_echo('form:at') . " " . $friendly_time_updated; 
      }
      $form_body .= "<br>";
      $wwwroot = elgg_get_config('wwwroot');
      $img_template = '<img border="0" width="16" height="16" alt="%s" title=
"%s" src="'.$wwwroot.'mod/form/graphics/%s" />';
      $url_export_pdf=elgg_add_action_tokens_to_url(elgg_get_site_url() . "action/form/export_pdf?formpost=$formpost&user_guid=$user_guid");
      $text_export_pdf=elgg_echo("form:export_pdf");
      $img_export_pdf = sprintf($img_template,$text_export_pdf,$text_export_pdf,"pdf_icon.gif");
      $form_body .= "<a href=\"{$url_export_pdf}\">{$img_export_pdf}</a>";

      //Comments
      $num_comments =  $user_response->countComments();
      if ($num_comments>0)
         $comments_label = elgg_echo('form:comments_label') . " (" . $num_comments . ")";
      else
         $comments_label = elgg_echo('form:comments_label');      
      $form_body .= "<p align=\"left\"><a onclick=\"form_show_comments();\" style=\"cursor:hand;\">$comments_label</a></p>";
      $form_body .= "<div id=\"comments_responseDiv\" style=\"display:none;\">";
      $form_body .= elgg_view_comments($user_response);
      $form_body .= "</div>";

      $form_body .= "</div>";
      $form_body .= "<br>";
      
   }

   echo($form_body);
    
   $form_body = "";

   if (!empty($user_response)) {

      //Questions
      $options = array('relationship' => 'form_question', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_question','limit'=>0);
      $questions=elgg_get_entities_from_relationship($options);
      if (empty($questions)) {
         $num_questions=0;
      } else {
         $num_questions=count($questions);
      }

      //Each question
      $index=0;
      while ($index<$num_questions) {

         $options = array('relationship' => 'form_question', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_question','metadata_name_value_pairs' => array('name' => 'index', 'value' => $index));
         $questions=elgg_get_entities_from_relationship($options);
         $one_question=$questions[0];

         $question=$one_question->question;
         $question_guid=$one_question->getGUID();
         $question_text = "<div class=\"form_question_frame\">";
         $question_text .= elgg_view('output/text', array('value' => $question));
         $question_text .= "</div>";

         $question_body ="";
         if (strcmp($one_question->question_html,"")!=0){
            $question_body .= "<p>" . "<b>" . elgg_echo('form:question_simple_read') . "</b>" . "</p>";
	    $question_body .= "<div class=\"form_question_frame\">";
            $question_body .= elgg_view('output/longtext', array('value' => $one_question->question_html));
	    $question_body .= "</div>";
	 
         }
         
         $response_type=$one_question->response_type;
         if ((strcmp($response_type,"radiobutton")==0)||(strcmp($response_type,"checkbox")==0)){ 
	    $responses_alignment=$one_question->responses_alignment;
            $responses=$one_question->responses;
         } else {
            if (strcmp($response_type,"grid")==0){ 
               $responses_rows=$one_question->responses_rows;
	       $responses_rows_array = explode(Chr(26),$responses_rows);
               $responses_rows_array = array_map('trim', $responses_rows_array);
	       $responses_columns=$one_question->responses_columns;
	       $responses_columns_array = explode(Chr(26),$responses_columns);
               $responses_columns_array = array_map('trim', $responses_columns_array);
            }
         }

         //Response

         if ((strcmp($response_type,"text")==0)||(strcmp($response_type,"html")==0)){
            $this_response=$user_response_content_array[$index];
	    if (strcmp($this_response,"not_response")==0)
	       $this_response="";               
         }
 
         if (strcmp($response_type,"urls_files")==0){
            $this_response=$user_response_content_array[$index];
            if (strcmp($this_response,"not_response")==0){
               $response_urls="";
            } else {
               $this_response_urls = explode(Chr(26),$this_response);
               $this_response_urls = array_map('trim',$this_response_urls);
               $response_urls = "";
               if ((count($this_response_urls)>0)&&(strcmp($this_response_urls[0],"")!=0)) {
                  foreach ($this_response_urls as $one_url){
                     $comp_url = explode(Chr(24),$one_url);
                     $comp_url = array_map('trim',$comp_url);
                     $url_name = $comp_url[0];
                     $url_value = $comp_url[1];
                     $response_urls .= "<a rel=\"nofollow\" href=\"$url_value\" target=\"_blank\">$url_name</a><br>";
                  }
               }
            }
	    if (!$form->subgroups) {
	       $response_files = elgg_get_entities_from_relationship(array('relationship' => 'response_file_link','relationship_guid' => $question_guid,'inverse_relationship' => false,'type' => 'object','subtype' => 'form_response_file','owner_guid' => $user_guid,'limit'=>0)); 
            } else {
               $response_files = elgg_get_entities_from_relationship(array('relationship' => 'response_file_link','relationship_guid' => $question_guid,'inverse_relationship' => false,'type' => 'object','subtype' => 'form_response_file','container_guid' => $user_guid,'limit'=>0)); 
            }
            $response_file_guids="";
            if ((count($response_files)>0)&&(strcmp($response_files[0]->title,"")!=0)){
               foreach($response_files as $file){
                  if (strcmp($response_file_guids,"")==0)
                     $response_file_guids .= $file->getGUID();
                  else
                     $response_file_guids .= "," . $file->getGUID();
               }
            }    
            $response_file_guids_array=explode(",",$response_file_guids);
         }
      
         if ((strcmp($response_type,"radiobutton")==0)||(strcmp($response_type,"checkbox")==0)){ 
            $responses_array = explode(Chr(26),$responses);
            $responses_array =  array_map('trim',$responses_array);
            $response_inputs = array();
	    foreach ($responses_array as $one_response){
	       $response_inputs[$one_response]=$one_response;
	    }
	    if (strcmp($response_type,"checkbox")==0){
               $this_responses=explode(Chr(26),$user_response_content_array[$index]); 
	       $this_responses =  array_map('trim',$this_responses);
            } else {
               $this_responses=$user_response_content_array[$index];
            }
         }

         if (strcmp($response_type,"grid")==0){
            $this_responses=explode(Chr(26),$user_response_content_array[$index]);  
            $this_responses =  array_map('trim',$this_responses);
         }
      
         $num_question = $index+1;

         switch($response_type){
            case 'text':
	       $form_body .= elgg_view("forms/form/show_answer_question",array('form'=>$form,'num_question'=>$num_question,'question_text'=>$question_text,'question_body'=>$question_body,'response_type'=>$response_type,'this_response'=>$this_response));
               break;
            case 'html':
	       $form_body .= elgg_view("forms/form/show_answer_question",array('form'=>$form,'num_question'=>$num_question,'question_text'=>$question_text,'question_body'=>$question_body,'response_type'=>$response_type,'this_response'=>$this_response));
               break; 
	    case 'radiobutton':
               $form_body .= elgg_view("forms/form/show_answer_question",array('form'=>$form,'num_question'=>$num_question,'question_text'=>$question_text,'question_body'=>$question_body,'response_type'=>$response_type,'response_inputs'=>$response_inputs,'this_responses'=>$this_responses,'responses_alignment'=>$responses_alignment));
               break;
            case 'checkbox':
	       $form_body .= elgg_view("forms/form/show_answer_question",array('form'=>$form,'num_question'=>$num_question,'question_text'=>$question_text,'question_body'=>$question_body,'response_type'=>$response_type,'response_inputs'=>$response_inputs,'this_responses'=>$this_responses,'responses_alignment'=>$responses_alignment));
	       break;
	    case 'grid':
	       $form_body .= elgg_view("forms/form/show_answer_question",array('form'=>$form,'num_question'=>$num_question,'question_text'=>$question_text,'question_body'=>$question_body,'response_type'=>$response_type,'responses_rows_array'=>$responses_rows_array,'responses_columns_array'=>$responses_columns_array,'this_responses'=>$this_responses));
               break;
	    case 'urls_files':
               $form_body .= elgg_view("forms/form/show_answer_question",array('form'=>$form,'num_question'=>$num_question,'question_text'=>$question_text,'question_body'=>$question_body,'response_type'=>$response_type,'response_urls'=>$response_urls,'response_file_guids_array'=>$response_file_guids_array));
               break;
         } 
         $index = $index+1;
      }   
     
      echo elgg_echo($form_body);  
  
   } else {
      $form_body .= "<p>" . elgg_echo('form:not_response') . "</p>";
      echo elgg_echo($form_body);
   }
   
}

?>
</div>

<script type="text/javascript">
   function form_show_general_comments(){
      var commentsDiv = document.getElementById('commentsDiv');
      if (commentsDiv.style.display == 'none'){
         commentsDiv.style.display = 'block';
      } else {       
         commentsDiv.style.display = 'none';
      }
   }   

   function form_show_comments(){
      var comments_responseDiv = document.getElementById('comments_responseDiv');
      if (comments_responseDiv.style.display == 'none'){
         comments_responseDiv.style.display = 'block';
      } else {       
         comments_responseDiv.style.display = 'none';
      }
   }    

</script>

