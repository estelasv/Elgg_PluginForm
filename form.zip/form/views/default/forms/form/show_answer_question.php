<?php

$form=$vars['form'];
$num_question=$vars['num_question'];
$question_text=$vars['question_text'];
$question_body=$vars['question_body'];
$response_type=$vars['response_type'];

switch ($response_type){
   case 'text':
      $this_response=$vars['this_response'];
      break;
   case 'html':
      $this_response=$vars['this_response'];
   case 'radiobutton':
      $this_responses=$vars['this_responses'];
      $response_inputs=$vars['response_inputs'];
   case 'checkbox':
      $this_responses=$vars['this_responses'];
      $response_inputs=$vars['response_inputs'];
      $responses_alignment=$vars['responses_alignment'];
   case 'grid':
      $this_responses=$vars['this_responses'];
      $responses_rows_array=$vars['responses_rows_array'];
      $responses_columns_array=$vars['responses_columns_array'];
      break;
   case 'urls_files':
      $response_urls=$vars['response_urls'];
      $response_file_guids_array=$vars['response_file_guids_array'];
      break;

}

$form_body = "";

$form_body .= "<div class=\"form_frame_blue\">";
// Question
$form_body .= "<p><b>" . elgg_echo('form:question_label') . " $num_question" . "</b></p>"; 
$form_body .= $question_text . "<br>";
if (strcmp($question_body,"")!=0){
   $form_body .=  $question_body;
   $form_body .= "<br>";
}

$form_body .= "</div>";
$form_body .= "<br>";

$form_body .= "<div class=\"form_frame_green\">";
// Response
if (strcmp($response_type,"text")==0){
   $form_body .= "<p><b>" . elgg_echo('form:response_label') . "</p></b>";
   $form_body .= "<div class=\"form_question_frame\">";
   $form_body .=  elgg_view('output/text',array('value' => $this_response));
   $form_body .= "</div><br>";
}

if (strcmp($response_type,"html")==0){
   $form_body .= "<p><b>" . elgg_echo('form:response_label') . "</p></b>";
   $form_body .= "<div class=\"form_question_frame\">";
   $form_body .=  elgg_view('output/longtext',array('value' => $this_response));
   $form_body .= "</div><br>";
}

if (strcmp($response_type,"urls_files")==0){
   $form_body .= "<p><b>" . elgg_echo('form:response_urls_files_label') . "</b></p>";
   $form_body .= "<div class=\"form_question_frame\">";
   if (strcmp($response_urls,"")!=0){
      $form_body .=  $response_urls;         
   }
   if ((count($response_file_guids_array)>0)&&(strcmp($response_file_guids_array[0],"")!=0)){
      foreach($response_file_guids_array as $one_file_guid){
         $response_file=get_entity($one_file_guid);
         $params = $one_file_guid . "_response";
         $form_body .= "<a href=\"" . elgg_get_site_url() . "mod/form/download.php?params=$params" . "\">" . $response_file->title . "</a><br>";
      }
   }
   $form_body .= "</div><br>";
}

if ((strcmp($response_type,"radiobutton")==0)||(strcmp($response_type,"checkbox")==0)){ 
   $form_body .= "<p><b>" . elgg_echo('form:response_label') . "</p></b>";
   if (strcmp($response_type,"checkbox")==0){
      $form_body .=  elgg_view('input/checkboxes',array('align'=>$responses_alignment,'disabled' => 'yes','options' => $response_inputs, 'value' => $this_responses)) . "<br>";
   } else {
      $form_body .=  elgg_view('input/radio',array('align'=>$responses_alignment,'disabled' => 'yes', 'options' => $response_inputs, 'value' => $this_responses)) . "<br>";
   }
   $form_body .= "<br>";
}

if (strcmp($response_type,"grid")==0){
   $i=$num_question-1; 
   $form_body .= "<p><b>" . elgg_echo('form:response_label') . "</p></b>";
   $j=0;
   foreach($responses_rows_array as $one_row){
      $form_body .= "<p>" . $one_row . "</p>";
      foreach ($responses_columns_array as $one_response_column){
         if ($this_responses[$j]==$one_response_column){
            $checked = "checked = \"checked\"";
         } else {
            $checked = "";
         }
         $form_body .= "<input type=\"radio\" disabled value=$one_response_column $checked >$one_response_column" . "<br>";
      }
      $j=$j+1;
   }
   $form_body .= "<br>";
}
	   
$form_body .= "</div>";
$form_body .= "<br>";

echo elgg_echo($form_body);

?>

