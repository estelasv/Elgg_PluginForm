<div class="contentWrapper">

<?php

$formpost=$vars['entity']->getGUID();
$form = get_entity($formpost);
$action = "form/edit";

if (form_check_status($form)){

   $form_opened = elgg_echo('form:opened');
   $close_form = elgg_echo('form:close');
   $form_body = "";
   $form_body .= "<p>" . $form_opened . "</p>";
   $entity_hidden = elgg_view('input/hidden', array('name' => 'formpost', 'value' => $formpost));
   $entity_hidden .= elgg_view('input/hidden', array('name' => 'close_form', 'value' => "yes"));
   $submit_input = elgg_view('input/submit', array('name' => 'submit', 'value' => $close_form));
   $form_body .= "<p>" . $submit_input . $entity_hidden . $entity_hidden_2 . "</p>";
   $url = elgg_get_site_url();
   echo elgg_view('input/form', array('action' => "{$url}action/$action", 'body' => $form_body));

} else {

   $options = array('relationship' => 'form_question', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_question','limit'=>0);
   $questions=elgg_get_entities_from_relationship($options);

   $created=$form->created;
   $count_responses=$form->countAnnotations('all_responses');
   
   if (!elgg_is_sticky_form('edit_form')) {
      $title = $form->title;
      $description = $form->description;
      $confirm_correct_answer = $form->confirm_correct_answer;
      $opendate = $form->form_activate_date;
      $opentime = $form->form_activate_time;
      $closedate = $form->form_close_date;
      $closetime = $form->form_close_time;
      $option_activate_value = $form->option_activate_value;
      $option_close_value = $form->option_close_value;
      //$visibility = $form->visibility;	
      $subgroups = $form->subgroups;
      $tags = $form->tags;
      $access_id = $form->access_id;
   } else { 
      $title = elgg_get_sticky_value('edit_form','title');
      $description = elgg_get_sticky_value('edit_form','description');
      $confirm_correct_answer = elgg_get_sticky_value('edit_form','confirm_correct_answer');
      $opendate = elgg_get_sticky_value('edit_form','opendate');
      $closedate = elgg_get_sticky_value('edit_form','closedate');
      $opentime = elgg_get_sticky_value('edit_form','opentime');
      $closetime = elgg_get_sticky_value('edit_form','closetime');
      $option_activate_value = elgg_get_sticky_value('edit_form','option_activate_value');
      $option_close_value = elgg_get_sticky_value('edit_form','option_close_value');  
      //$visibility = elgg_get_sticky_value('edit_form','visibility');
      $subgroups = elgg_get_sticky_value('edit_form','subgroups');
      $tags = elgg_get_sticky_value('edit_form','formtags');
      $access_id = elgg_get_sticky_value('edit_form','access_id');
   }

   elgg_clear_sticky_form('edit_form');

   if (strcmp($opentime,"")==0)
      $opentime = "00:00";

   if (strcmp($closetime,"")==0)
      $closetime = "00:00";

   if (empty($questions)) {
      $num_questions = 0;
   } else {
      $num_questions = count($questions);
   }
      
   $options_activate=array();
   $options_activate[0]=elgg_echo('form:activate_now');
   $options_activate[1]=elgg_echo('form:activate_date');
   $op_activate=array();
   $op_activate[0]='form_activate_now';
   $op_activate[1]='form_activate_date';
   if (strcmp($option_activate_value,$op_activate[0])==0){
       $checked_radio_activate_0 = "checked = \"checked\"";
       $checked_radio_activate_1 = "";
       $style_display_activate = "display:none";
   } else {
      $checked_radio_activate_0 = "";
      $checked_radio_activate_1 = "checked = \"checked\"";
      $style_display_activate = "display:block";
   }
   $options_close=array();
   $options_close[0]=elgg_echo('form:not_close');
   $options_close[1]=elgg_echo('form:close_date');
   $op_close=array();
   $op_close[0]='form_not_close';
   $op_close[1]='form_close_date';
   if (strcmp($option_close_value,$op_close[0])==0){
       $checked_radio_close_0 = "checked = \"checked\"";
       $checked_radio_close_1 = "";
       $style_display_close = "display:none";
   } else {
      $checked_radio_close_0 = "";
      $checked_radio_close_1 = "checked = \"checked\"";
      $style_display_close = "display:block";
   }
   $opendate_label = elgg_echo('form:opendate');
   $closedate_label = elgg_echo('form:closedate');
   $opentime_label = elgg_echo('form:opentime');
   $closetime_label = elgg_echo('form:closetime');

   if ($count_responses>0) {
      $disabled = "disabled";
   } else {
      $disabled = "";
   }

   $confirm_correct_answer_label = elgg_echo('form:confirm_correct_answer_label');
   if ($confirm_correct_answer){
      $selected_confirm_correct_answer = "checked = \"checked\"";
   } else {
      $selected_confirm_correct_answer = "";
   }

   //$visibility_label = elgg_echo('form:visibility_label');
   //if ($visibility){
   //   $selected_visibility = "checked = \"checked\"";
   //} else {
   //   $selected_visibility = "";
   //}

   $subgroups_label = elgg_echo('form:subgroups_label');
   if ($subgroups){
      $selected_subgroups = "checked = \"checked\"";
   } else {
      $selected_subgroups = "";
   }

   $tag_label = elgg_echo('tags');
   $tag_input = elgg_view('input/tags', array('name' => 'formtags', 'value' => $tags));   
   $access_label = elgg_echo('access');
   $access_input = elgg_view('input/access', array('name' => 'access_id', 'value' => $access_id));

   if ($num_questions>0){
      $form_questions_label = elgg_echo('form:questions');
      $form_questions = elgg_view('form/form_questions_table', array('entity' => $form));
   }

   $form_add_question=elgg_echo('form:add_question');
   $form_save=elgg_echo('form:save');
   $form_publish=elgg_echo('form:publish');
       	
   $submit_input_add_question = elgg_view('input/submit', array('name' => 'submit', 'value' => $form_add_question));
   $submit_input_save = elgg_view('input/submit', array('name' => 'submit', 'value' => $form_save));
   $submit_input_publish = elgg_view('input/submit', array('name' => 'submit', 'value' => $form_publish));
        
   ?>

   <form action="<?php echo elgg_get_site_url()."action/".$action?>" name="edit_form" enctype="multipart/form-data" method="post">

   <?php echo elgg_view('input/securitytoken'); ?>

   <p>
   <b><?php echo elgg_echo("form:title_label"); ?></b><br>
   <?php echo elgg_view("input/text", array('name' => 'title', 'value' => $title)); ?>
   </p>
  
   <p>
   <b><?php echo elgg_echo("form:description_label"); ?></b><br>
   <?php echo elgg_view("input/longtext", array('name' => 'description', 'value' => $description)); ?>
   </p>

   <table class="form_dates_table">
   <tr>
   <td>
   <p>
   <b><?php echo elgg_echo('form:activate_label'); ?></b><br>
   <?php echo "<input type=\"radio\" name=\"option_activate_value\" value=$op_activate[0] $checked_radio_activate_0 onChange=\"form_show_activate_time()\">$options_activate[0]";?><br> 
   <?php echo "<input type=\"radio\" name=\"option_activate_value\" value=$op_activate[1] $checked_radio_activate_1 onChange=\"form_show_activate_time()\">$options_activate[1]";?><br> 
   <div id="resultsDiv_activate" style="<?php echo $style_display_activate;?>;"> 
      <?php echo $opendate_label; ?><br> 
      <?php echo elgg_view('input/date',array('timestamp'=>TRUE, 'autocomplete'=>'off','class'=>'form-compressed-date','name'=>'opendate','value'=>$opendate)); ?>
      <?php echo "<br>" . $opentime_label; ?> <br> 
      <?php echo "<input type = \"text\" name = \"opentime\" value = $opentime>"; ?>  
   </div>
   </p><br>
   </td>
<td>
   <p>
   <b><?php echo elgg_echo('form:close_label'); ?></b><br>
   <?php echo "<input type=\"radio\" name=\"option_close_value\" value=$op_close[0] $checked_radio_close_0 onChange=\"form_show_close_time()\">$options_close[0]";?><br> 
   <?php echo "<input type=\"radio\" name=\"option_close_value\" value=$op_close[1] $checked_radio_close_1 onChange=\"form_show_close_time()\">$options_close[1]";?><br>
   <div id="resultsDiv_close" style="<?php echo $style_display_close;?>;">
      <?php echo $closedate_label; ?><br> 
      <?php echo elgg_view('input/date',array('timestamp'=>TRUE, 'autocomplete'=>'off','class'=>'form-compressed-date','name'=>'closedate','value'=>$closedate)); ?>
      <?php echo "<br>" . $closetime_label; ?> <br> 
      <?php echo "<input type = \"text\" name = \"closetime\" value = $closetime>"; ?>  
   </div>
   </p><br>
   </td>
   </tr>
   </table>

   <p>
   <b>
   <?php echo "<input type = \"checkbox\" name = \"confirm_correct_answer\" $selected_confirm_correct_answer> $confirm_correct_answer_label"; ?>
   </b>         
   </p><br>
   <!--<p>
   <b>
   <?php //echo "<input type = \"checkbox\" name = \"visibility\" $selected_visibility> $visibility_label"; ?>
   </b>         
   </p><br>-->
   <?php $container = $form->getContainerEntity();
     if (!($container->getContainerEntity() instanceof ElggGroup)){ ?>
   <p>
   <b>
   <?php echo "<input type = \"checkbox\" $disabled name = \"subgroups\" $selected_subgroups> $subgroups_label"; ?>
   </b> 
   </p><br>
   <?php } ?>
   <p>
   <b><?php echo $tag_label; ?></b><br />
   <?php echo $tag_input; ?>
   </p><br>
   <p>
   <b><?php echo $access_label; ?></b><br />
   <?php echo $access_input; ?>
   </p> 

   <?php
   if ($num_questions>0){
      ?>
      <b>
      <?php echo $form_questions_label; ?></b><br>
      <?php echo $form_questions; ?><br>
      <?php 
   }

   if ($created){       
      if ($count_responses>0){
         echo ($submit_input_save);
      } else {
         echo "$submit_input_add_question $submit_input_save";
      }
   } else {
      if ($num_questions>0) {
         echo "$submit_input_add_question $submit_input_save $submit_input_publish";
      } else {
         echo "$submit_input_add_question $submit_input_save"; 
      }
   }
   
   ?>
   <input type="hidden" name="formpost" value="<?php echo $formpost; ?>">
	
</form>

<?php
}
?>

<script language="javascript">
   function form_show_activate_time(){
      var resultsDiv_activate = document.getElementById('resultsDiv_activate');
      if (resultsDiv_activate.style.display == 'none'){
         resultsDiv_activate.style.display = 'block';
      } else {       
         resultsDiv_activate.style.display = 'none';
      }
   }   
   function form_show_close_time(){
      var resultsDiv_close = document.getElementById('resultsDiv_close');
      if (resultsDiv_close.style.display == 'none'){
            resultsDiv_close.style.display = 'block';
      } else {       
         resultsDiv_close.style.display = 'none';
      }
   }  
</script>

</div>


