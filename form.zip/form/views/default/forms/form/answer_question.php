<?php

$form=$vars['form'];
$num_question=$vars['num_question'];
$question_text=$vars['question_text'];
$question_body=$vars['question_body'];
$response_type=$vars['response_type'];
switch($response_type){
   case 'text':
      $response_text=$vars['response_text'];
      break;
   case 'html':
      $response_html=$vars['response_html'];
      break;
   case 'radiobutton':
      $response_inputs=$vars['response_inputs'];
      break;
   case 'checkbox':
      $response_inputs=$vars['response_inputs'];
      break;
   case 'grid':
      $responses_rows_array=$vars['responses_rows_array'];
      $grid_response_inputs=$vars['grid_response_inputs'];
      break;
   case 'urls_files':
      $response_urls=$vars['response_urls'];
      $response_file=$vars['response_file'];
      $response_files=$vars['response_files'];
      break;
}
$obligatory_response=$vars['obligatory_response'];

//Question
?>
<div class="form_frame_blue">

   <p>
   <b><?php echo elgg_echo('form:question_label') . " " . $num_question; ?></b>
   </p>
   <?php echo $question_text; ?>
   <br>
   <?php
   if (strcmp($question_body,"")!=0){
      echo $question_body;
      echo "<br>";
   }
   ?>
</div>
<br>

<?php

if (!$obligatory_response)
   $response_label = elgg_echo("form:response_label");
else
   $response_label = elgg_echo("form:response_label") . " (" . elgg_echo("form:obligatory") . ")";
	
//Response
?>

<div class="form_frame_green">
   <?php
   switch($response_type){
      case 'text':
         ?>
         <p><b><?php echo $response_label; ?></b></p>
         <p><?php echo $response_text; ?></p>
         <?php    
         break;
      case 'html':
         ?>
         <p><b><?php echo $response_label; ?></b></p>
         <?php echo $response_html; ?>
         <?php
         break;
      case 'radiobutton':
         ?>
         <p><b><?php echo $response_label; ?></b></p>
         <p><?php echo $response_inputs; ?></p>
         <?php
         break;
      case 'checkbox':
         ?>
         <p><b><?php echo $response_label; ?></b></p>
         <p><?php echo $response_inputs; ?></p>
         <?php
         break;
       case 'grid':
         ?>
         <p><b><?php echo $response_label; ?></b></p>
         <?php 
         $j=0;
         foreach ($responses_rows_array as $one_row){
            ?>
            <p><?php echo $one_row; ?></p>
            <p><?php echo $grid_response_inputs[$j]; ?></p>
            <?php
            $j=$j+1;
         }
         break;
      case 'urls_files':
         ?>
	 <p><b><?php echo $response_label; ?></b></p>
         <p><b><?php echo elgg_echo("form:response_urls_label"); ?></b></p>
         <?php echo $response_urls; ?>

         <p><b><?php echo elgg_echo("form:response_files_label"); ?></b></p>
         <p><?php echo $response_file; ?></p>
         <?php
         $response_multifile = "";
         if ((count($response_files)>0)&&(strcmp($response_files[0]->title,"")!=0)){
            foreach($response_files as $file) {
               ?>
               <div class="file_wrapper">
               <a class="bold" onclick="changeFormValue(<?php echo $file->getGUID(); ?>), changeImage(<?php echo $file->getGUID(); ?>)">
               <img id ="image_<?php echo $file->getGUID(); ?>" src="<?php echo elgg_get_site_url(); ?>mod/form/graphics/tick.jpeg">
               </a>
               <span><?php echo $file->title ?></span>
               <?php
               echo elgg_view("input/hidden",array('name' => $file->getGUID(), 'internalid'=> $file->getGUID(), 'value' => '0'));
               ?>
               </div>
               <br>
               <?php
            }
         }            
         break;
   }   
?>
</div>
<br>

<script type="text/javascript">
    function changeImage(num) {
        if (document.getElementById('image_'+num).src == "<?php echo elgg_get_site_url(); ?>mod/form/graphics/tick.jpeg")
            document.getElementById('image_'+num).src = "<?php echo elgg_get_site_url(); ?>mod/form/graphics/delete_file.jpeg";
        else
            document.getElementById('image_'+num).src = "<?php echo elgg_get_site_url(); ?>mod/form/graphics/tick.jpeg";
    }
</script>