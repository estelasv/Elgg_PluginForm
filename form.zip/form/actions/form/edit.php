<?php

gatekeeper();

$formpost = get_input('formpost');
$form = get_entity($formpost);
$close_form = get_input('close_form');
   
if (strcmp($close_form,"yes")==0){
   $form->option_close_value = 'form_not_close';
   $form->opened=false;
   // Delete the event created with the form (if event_manager plugin)
   if (elgg_is_active_plugin('event_manager')){
      $event_guid=$form->event_guid;
      if ($event=get_entity($event_guid)){
         $deleted=$event->delete();
         if (!$deleted){
           register_error(elgg_echo("form:eventmanagernotdeleted"));
           forward(elgg_get_site_url() . 'form/group/' . $container_guid);
         }
         else
            system_message(elgg_echo("event_manager:action:event:delete:ok"));
      }
   }
   forward("form/edit/$formpost");  
} 

if ($form->getSubtype() == "form" && $form->canEdit()) {

   $user_guid = elgg_get_logged_in_user_guid();
   $user = get_entity($user_guid);

   $title = (get_input('title'));
   $description = get_input('description');
   $confirm_correct_answer = get_input('confirm_correct_answer');
   $option_activate_value = get_input('option_activate_value');
   $option_close_value = get_input('option_close_value');
   if (strcmp($option_activate_value,'form_activate_date')==0){
      $opendate = get_input('opendate');
      $opentime = get_input('opentime');
   }
   if (strcmp($option_close_value,'form_close_date')==0){
      $closedate = get_input('closedate');
      $closetime = get_input('closetime');
   }
   //$visibility = get_input('visibility');
   $tags = get_input('formtags');
   $access_id = get_input('access_id');
   $selected_action = get_input('submit');

   $container_guid = $form->container_guid;
   $container = get_entity($container_guid);	

   $count_responses=$form->countAnnotations('all_responses');

   if ($count_responses==0){
      $subgroups = get_input('subgroups');
   } 

   $form_publish=elgg_echo('form:publish');
   $form_save=elgg_echo('form:save');
   $form_add_question=elgg_echo('form:add_question');

   $now=time();

   // Cache to the session
   elgg_make_sticky_form('edit_form');

   $options = array('relationship' => 'form_question', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_question','limit'=>0);
   $questions=elgg_get_entities_from_relationship($options);
   if (empty($questions)) {
      $num_questions = 0;
   } else {
      $num_questions = count($questions);
   }
	
   //////////////////////////////////////////////////////////////////////////
	
   if (((strcmp($selected_action,$form_save)==0)&&($form->created)&&($num_questions==0))||((strcmp($selected_action,$form_publish)==0)&&($num_questions==0))){
      register_error(elgg_echo("form:not_questions"));
      forward("form/edit/$formpost");
   }

   //////////////////////////////////////////////////////////////////////////
	
   //Times
   if (strcmp($option_activate_value,'form_activate_date')==0){
      $mask_time="[0-2][0-9]:[0-5][0-9]";
      if (!ereg($mask_time,$opentime,$same)){
         register_error(elgg_echo("form:bad_times"));
	 forward("form/edit/$formpost");
      }
   }
   if (strcmp($option_close_value,'form_close_date')==0){
      $mask_time="[0-2][0-9]:[0-5][0-9]";
      if (!ereg($mask_time,$closetime,$same)){
	  register_error(elgg_echo("form:bad_times"));
	  forward("form/edit/$formpost");
      }
   }
   if (strcmp($option_activate_value,'form_activate_now')==0){
      $activate_time=$now;
   } else {
      $opentime_array = explode(':',$opentime);
      $opentime_h = trim($opentime_array[0]);
      $opentime_m = trim($opentime_array[1]);
      $opendate_text = date("Y-m-d",$opendate);
      $opendate = strtotime($opendate_text." ".date_default_timezone_get());
      $opendate_array = explode('-',$opendate_text);
      $opendate_y = trim($opendate_array[0]);
      $opendate_m = trim($opendate_array[1]);
      $opendate_d = trim($opendate_array[2]);
      $activate_date = mktime(0,0,0,$opendate_m,$opendate_d,$opendate_y);
      $activate_time = mktime($opentime_h,$opentime_m,0,$opendate_m,$opendate_d,$opendate_y);

      if ($activate_time < 1){
         register_error(elgg_echo("form:bad_times"));
         forward("form/edit/$formpost");
      }
   }
   if (strcmp($option_close_value,'form_not_close')==0){
      $close_time=$now+1;
   } else {
      $closetime_array = explode(':',$closetime);
      $closetime_h = trim($closetime_array[0]);
      $closetime_m = trim($closetime_array[1]);
      $closedate_text = date("Y-m-d",$closedate);
      $closedate = strtotime($closedate_text." ".date_default_timezone_get());
      $closedate_array = explode('-',$closedate_text);
      $closedate_y = trim($closedate_array[0]);
      $closedate_m = trim($closedate_array[1]);
      $closedate_d = trim($closedate_array[2]);
      $close_date = mktime(0,0,0,$closedate_m,$closedate_d,$closedate_y);
      $close_time = mktime($closetime_h,$closetime_m,0,$closedate_m,$closedate_d,$closedate_y);

      if ($close_time < 1){
         register_error(elgg_echo("form:bad_times"));
         forward("form/edit/$formpost");
      }
   }
   if ($activate_time>=$close_time) {
      register_error(elgg_echo("form:error_times"));
      forward("form/edit/$formpost");
   }
	
//////////////////////////////////////////////////////////////////////////

   // Convert string of tags into a preformatted array
   $tagarray = string_to_tag_array($tags);
	
   // Make sure the title and description aren't blank
   if ((strcmp($title,"")==0) || (strcmp($description,"")==0)) {	
      register_error(elgg_echo("form:blank"));
      forward("form/edit/$formpost");
   } 
		
   // Set its access
   $form->access_id = $access_id;

   // Set its title 
   $form->title= $title;

   // Set its description
   $form->description= $description;

   // Before we can set metadata, we need to save the form post
   if (!$form->save()) {
      register_error(elgg_echo("form:error_save"));
      forward("form/edit/$formpost");
   }		

   // Set send confirmation of correct answer
   $form->confirm_correct_answer = $confirm_correct_answer;

   //Set times
   $form->option_activate_value = $option_activate_value;
   $form->option_close_value = $option_close_value;
   if (strcmp($option_activate_value,'form_activate_now')!=0){
      $form->activate_date = $activate_date;
      $form->activate_time = $activate_time;
      $form->form_activate_date = $activate_date;
      $form->form_activate_time = $opentime;
   }
   if (strcmp($option_close_value,'form_not_close')!=0){
      $form->close_date = $close_date;
      $form->close_time = $close_time;
      $form->form_close_date = $close_date;
      $form->form_close_time = $closetime;
   }
   if ((strcmp($option_activate_value,'form_activate_date')==0)&&(strcmp($option_close_value,'form_close_date')==0)){
      if (($now>=$activate_time)&&($now<$close_time)){
         $form->opened=true;
      } else {
         $form->opened=false;
      }
   } elseif (strcmp($option_activate_value,'form_activate_date')==0){
      if ($now>=$activate_time) {
         $form->opened=true;
      } else {
         $form->opened=false;
      }
   } elseif (strcmp($option_close_value,'form_close_date')==0){
      if ($now<$close_time) {
         $form->opened=true;
      } else {
         $form->opened=false;
      } 
   } else {
      $form->opened=true;
   }

   // Set visibility
   //if (strcmp($visibility,"on")==0) {
   //   $form->visibility=true;
   //} else { 
   //   $form->visibility=false;
   //}

   if ($count_responses==0){

      // Set subgroups
      if (strcmp($subgroups,"on")==0) {
         $form->subgroups=true;
	 $form->who_answers='subgroup';
      } else { 
         $form->subgroups=false;
	 $form->who_answers='member';
      }
   }
		
   // Now let's add tags.
   if (is_array($tagarray)) {
      $form->tags = $tagarray;
   }
		
   // Questions access
   if (!empty($questions)){
      foreach ($questions as $one_question){
         $one_question->access_id = $form->access_id;
         if (!$one_question->save()){
            register_error(elgg_echo("form:question_save_error"));
            forward("form/edit/$formpost");
         }
      }
   }
	
   //Change access_id in answers
   $options = array('relationship' => 'form_answer', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_answer','limit'=>0);
   $users_responses=elgg_get_entities_from_relationship($options);
   foreach($users_responses as $one_response){
      if ($form->subgroups) {
         $response_subgroup_guid = $one_response->container_guid;
         $response_subgroup = get_entity($response_subgroup_guid);
      }
      //if (!$form->visibility){
         //compañeros y profesores
         if ($form->subgroups)
            $one_response->access_id = $response_subgroup->teachers_acl;
         else   
            $one_response->access_id = $container->teachers_acl;
      //} else {
      //   $one_response->access_id = $form->access_id;
      //}
      if (!$one_response->save()) {
         register_error(elgg_echo('form:answer_error_save'));
         forward("form/edit/$formpost");
      }
   }

   //Change access_id in files
   foreach ($questions as $one_question){
      $files_response = elgg_get_entities_from_relationship(array('relationship' => 'response_file_link','relationship_guid' => $one_question->getGUID(),'inverse_relationship' => false,'type' => 'object','limit'=>0));
      foreach($files_response as $one_file){
         if ($form->subgroups) {
            $file_subgroup_guid = $one_file->container_guid;
            $file_subgroup = get_entity($file_subgroup_guid);
         }
         //if (!$form->visibility){
            //compañeros y profesores
            if ($form->subgroups)
               $one_file->access_id = $file_subgroup->teachers_acl;
            else   
               $one_file->access_id = $container->teachers_acl;
         //} else {
         //   $one_file->access_id = $form->access_id;
         //}
         if (!$one_file->save()) {
            register_error(elgg_echo('form:file_error_save'));
            forward("form/edit/$formpost");
         }
      }
   }


   // Remove the form post cache
   elgg_clear_sticky_form('edit_form');
		
   // Forward 
   if (strcmp($selected_action,$form_publish)==0){
      $form->created = true;
      // Add to river
      elgg_create_river_item(array(
         'view'=>'river/object/form/create',
         'action_type'=>'create',
         'subject_guid'=>$user_guid,
         'object_guid'=>$formpost
      ));
      //Nofity 
      if ($access_id!=0) {
         $username = $user->name;
         $site_guid = elgg_get_config('site_guid');
         $site = get_entity($site_guid);
         $sitename = $site->name;
         $group = $container;
         $groupname = $container->name;
         $link = $form->getURL();
         $subject = sprintf(elgg_echo('form:create:group:email:subject'),$username,$sitename,$groupname);
         $group_members = $group->getMembers(array(false));
         foreach ($group_members as $member){
            $member_guid = $member->getGUID();
            if ($member_guid != $form->owner_guid){
               $body = sprintf(elgg_echo('form:create:group:email:body'),$member->name,$username,$sitename,$groupname,$title,$link);
               notify_user($member_guid,$form->owner_guid,$subject,$body, array('action'=> 'create', 'object'=> $form));
            }
         }
      }
      //Event using the event_manager plugin if it is active
      if (elgg_is_active_plugin('event_manager') && strcmp($option_close_value,'form_not_close')!=0){

         $event = new Event();
         $event->title = sprintf(elgg_echo("form:event_manager_title"),$form->title);
         $event->description = $input_question_html;
         $event->container_guid = $container_guid;
         $event->access_id = $access_id;
         $event->save();
         
         $event->tags = string_to_tag_array($tags);

         // add event create river event
         elgg_create_river_item(array(
            'view'=> 'river/object/event/create',
            'action_type'=> 'create',
            'subject_guid'=> elgg_get_logged_in_user_guid(),
            'object_guid'=> $event->getGUID()
         ));
         
         $event->comments_on = 0;
         $event->registration_ended = 1;
         $event->show_attendees = 0;
         $event->max_attendees = "";
         if (strcmp($option_activate_value,'form_activate_now')==0){
            $opentime_array = explode(':',date("H:i"));
            $opentime_h = trim($opentime_array[0]);
            $opentime_m = trim($opentime_array[1]);
            $opendate_array = explode('-',date("Y-m-d"));
            $opendate_y = trim($opendate_array[0]);
            $opendate_m = trim($opendate_array[1]);
            $opendate_d = trim($opendate_array[2]);
            $activate_date = mktime(0,0,0,$opendate_m,$opendate_d,$opendate_y);
            $activate_time = mktime($opentime_h,$opentime_m,0,$opendate_m,$opendate_d,$opendate_y);
         }
         $event->start_day = $close_date;
         $event->start_time = $close_time;
         $event->end_ts = $close_time+1;
         $event->organizer = $user->getDisplayName();
         $event->setAccessToOwningObjects($access_id);

         // added because we need an update event
         if ($event->save()){
            $event_guid = $event->getGUID();
            $form->event_guid = $event_guid;
            system_message(elgg_echo("event_manager:action:event:edit:ok"));
         }
         else
            register_error(elgg_echo("form:event_manager_error_save"));
      }
      //System message
      system_message(elgg_echo("form:created"));
      forward(elgg_get_site_url() . 'form/group/' . $container_guid);
   } elseif (strcmp($selected_action,$form_save)==0){
      if ($form->created){
         // Add to river
         elgg_create_river_item(array(
            'view'=>'river/object/form/update',
            'action_type'=>'update',
            'subject_guid'=>$user_guid,
            'object_guid'=>$formpost
         ));
	 //Nofity 
	 if ($access_id!=0) {
            $username = $user->name;
            $site_guid = elgg_get_config('site_guid');
            $site = get_entity($site_guid);
            $sitename = $site->name;
            $group = $container;
            $groupname = $container->name;
            $link = $form->getURL();
            $subject = sprintf(elgg_echo('form:update:group:email:subject'),$username,$sitename,$groupname);
            $group_members = $group->getMembers(array(false));
            foreach ($group_members as $member){
               $member_guid = $member->getGUID();
               if ($member_guid != $form->owner_guid){
                  $body = sprintf(elgg_echo('form:update:group:email:body'),$member->name,$username,$sitename,$groupname,$title,$link);
	               notify_user($member_guid,$form->owner_guid,$subject,$body, array('action'=> 'update', 'object'=> $form));
               }
            }
	 }
    //Event using the event_manager plugin if it is active
    if (elgg_is_active_plugin('event_manager') && strcmp($option_close_value,'form_not_close')!=0){

      $event_guid = $form->event_guid;
      if (!($event=get_entity($event_guid))){
         $newEvent = true;
         $event = new Event();
      } 

      $event->title = sprintf(elgg_echo("form:event_manager_title"),$form->title);
      $event->description = $form->getURL();
      $event->container_guid = $container_guid;
      $event->access_id = $access_id;
      $event->save();
   
      $event->tags = string_to_tag_array($tags);
      if ($newEvent) {
         // add event create river event
         elgg_create_river_item(array(
            'view'=> 'river/object/event/create',
            'action_type'=> 'create',
            'subject_guid'=> elgg_get_logged_in_user_guid(),
            'object_guid'=> $event->getGUID()
         ));
      }
   
      $event->comments_on = 0;
      $event->registration_ended = 1;
      $event->show_attendees = 0;
      $event->max_attendees = "";
      if (strcmp($option_activate_value,'form_activate_now')==0){
         $opentime_array = explode(':',date("H:i"));
         $opentime_h = trim($opentime_array[0]);
         $opentime_m = trim($opentime_array[1]);
         $opendate_array = explode('-',date("Y-m-d"));
         $opendate_y = trim($opendate_array[0]);
         $opendate_m = trim($opendate_array[1]);
         $opendate_d = trim($opendate_array[2]);
         $activate_date = mktime(0,0,0,$opendate_m,$opendate_d,$opendate_y);
         $activate_time = mktime($opentime_h,$opentime_m,0,$opendate_m,$opendate_d,$opendate_y);
      }
      $event->start_day = $close_date;
      $event->start_time = $close_time;
      $event->end_ts = $close_time+1;
      $event->organizer = $user->getDisplayName();
      $event->setAccessToOwningObjects($access_id);

      // Save it, if it is new
      if (!get_entity($event_guid)){         
         if ($event->save()){
            $event_guid = $event->getGUID();
            $form->event_guid = $event_guid;
            system_message(elgg_echo("event_manager:action:event:edit:ok"));
         }
         else
            register_error(elgg_echo("form:event_manager_error_save"));
      }
   } //end elgg_is_active_plugin
      
   }
      //System message
      system_message(elgg_echo("form:updated"));
      forward(elgg_get_site_url() . 'form/group/' . $container_guid);
   } else {
      $form->option_close_value = "form_not_close";
      $form->opened = false;
      forward("form/add_question/$formpost");
   }          
}

?>