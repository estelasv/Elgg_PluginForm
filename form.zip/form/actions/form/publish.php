<?php

gatekeeper();

$formpost = get_input('formpost');
$form = get_entity($formpost);

if ($form->getSubtype() == "form" && $form->canEdit()) {

   $options = array('relationship' => 'form_question', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_question','limit'=>0);
   $questions=elgg_get_entities_from_relationship($options);
   if (empty($questions)) {
      $num_questions = 0;
   } else {
      $num_questions = count($questions);
   }

   //Not questions
   if ($num_questions==0){
      register_error(elgg_echo("form:not_questions"));
      forward("form/edit/$formpost");
   }

   $form->created = true;

   $user_guid = elgg_get_logged_in_user_guid();
   $container_guid = $form->container_guid;
   $user = get_entity($user_guid);
   $container = get_entity($container_guid);

   //Nofity 
   if ($form->access_id!=0) {
      $username = $user->name;
      $site_guid = elgg_get_config('site_guid');
      $site = get_entity($site_guid);
      $sitename = $site->name;
      $group = $container;
      $groupname = $container->name;
      $link = $form->getURL();
      $subject = sprintf(elgg_echo('form:create:group:email:subject'),$username,$sitename,$groupname);
      $group_members = $group->getMembers(array('limit'=>false));
      foreach ($group_members as $member){
         $member_guid = $member->getGUID();
         if ($member_guid != $form->owner_guid){
            $body = sprintf(elgg_echo('form:create:group:email:body'),$member->name,$username,$sitename,$groupname,$title,$link);
            notify_user($member_guid,$form->owner_guid,$subject,$body, array('action'=> 'create', 'object'=> $form));
         }
      }
   }

   //Event using the event_manager plugin if it is active
   if (elgg_is_active_plugin('event_manager') && strcmp($form->option_close_value,'form_not_close')!=0){

      $event = new Event();
      $event->title = sprintf(elgg_echo("form:event_manager_title"),$form->title);
      $event->description = $form->input_question_html;
      $event->container_guid = $form->container_guid;
      $event->access_id = $form->access_id;
      $event->save();
         
      $event->tags = string_to_tag_array($form->tags);

      // add event create river event
      elgg_create_river_item(array(
         'view'=> 'river/object/event/create',
         'action_type'=> 'create',
         'subject_guid'=> elgg_get_logged_in_user_guid(),
         'object_guid'=> $event->getGUID()
      ));
         
      $event->comments_on = 0;
      $event->show_attendees = 0;
      $event->max_attendees = "";
      if (strcmp($form->option_activate_value,'form_activate_now')==0){
         $opentime_array = explode(':',date("H:i"));
         $opentime_h = trim($opentime_array[0]);
         $opentime_m = trim($opentime_array[1]);
         $opendate_array = explode('-',date("Y-m-d"));
         $opendate_y = trim($opendate_array[0]);
         $opendate_m = trim($opendate_array[1]);
         $opendate_d = trim($opendate_array[2]);
         $activate_date = mktime(0,0,0,$opendate_m,$opendate_d,$opendate_y);
         $activate_time = mktime($opentime_h,$opentime_m,0,$opendate_m,$opendate_d,$opendate_y);
      }
      $event->start_day = $form->close_date;
      $event->start_time = $form->close_time;
      $event->end_ts = $form->close_time+1;
      $event->organizer = $user->getDisplayName();
      $event->setAccessToOwningObjects($form->access_id);

      // added because we need an update event
      if ($event->save()){
         $event_guid = $event->getGUID();
         $form->event_guid = $event_guid;
         system_message(elgg_echo("event_manager:action:event:edit:ok"));
      }
      else
         register_error(elgg_echo("form:event_manager_error_save"));
   }
   //System message 
   system_message(elgg_echo("form:created"));
   //Forward
   forward($_SERVER['HTTP_REFERER']);
}
		
?>
