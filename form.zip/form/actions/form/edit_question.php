<?php

gatekeeper();

$formpost = get_input('formpost');
$form = get_entity($formpost);

if ($form->getSubtype() == "form" && $form->canEdit()) {

   $user_guid = elgg_get_logged_in_user_guid();

   $index = get_input('index');

   $count_responses=$form->countAnnotations('all_responses');
  
   $modification=false;

   $input_question = get_input('question');
   $input_obligatory_response = get_input('obligatory_response');
   $input_question_html = get_input('question_html');
   if ($count_responses==0)
      $input_response_type = get_input('response_type');
   else
      $input_response_type = $one_question->response_type;
   if ((strcmp($input_response_type,"radiobutton")==0)||(strcmp($input_response_type,"checkbox")==0)){
      $input_responses_alignment = get_input('responses_alignment');
      $responses = get_input('responses');
      $responses = array_map('trim', $responses);
      $input_responses = implode(Chr(26),$responses);
      $number_responses = count($responses);
   } else {
      if (strcmp($input_response_type,"grid")==0){
         $responses_rows = get_input('responses_rows');
         $responses_rows = array_map('trim', $responses_rows);
         $input_responses_rows = implode(Chr(26),$responses_rows);
         $number_responses_rows = count($responses_rows);
         $responses_columns = get_input('responses_columns');
         $responses_columns = array_map('trim', $responses_columns);
         $input_responses_columns = implode(Chr(26),$responses_columns);
         $number_responses_columns = count($responses_columns);
      }
   }
   $input_question_tags = get_input('question_tags');
   //Convert string of tags into a preformatted array
   $questiontagsarray = string_to_tag_array($input_question_tags);

   $options = array('relationship' => 'form_question', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_question', 'metadata_name_value_pairs' => array('name' => 'index', 'value' => $index));
   $questions=elgg_get_entities_from_relationship($options);
   $one_question = $questions[0];         

   if (empty($one_question)){
      register_error(elgg_echo('form:question_notfound'));
      forward("form/edit_question/$formpost/$index");
   }

   // Cache to the session
   elgg_make_sticky_form('edit_question_form');

   // Make sure the question isn't blank
   if (strcmp($input_question,"")==0) {	
      register_error(elgg_echo("form:question_blank"));
      forward("form/edit_question/$formpost/$index");
   } 

   // Responses
   if ((strcmp($input_response_type,"radiobutton")==0)||(strcmp($input_response_type,"checkbox")==0)){
      $blank_response=false;
      $responsesarray=array();
      $i=0;
      foreach($responses as $one_response){
         $responsesarray[$i]=$one_response;
         if (strcmp($one_response,"")==0){
            $blank_response=true;
            break;
	 }
	 $i=$i+1;
      }	           
      if ($blank_response){
         register_error(elgg_echo("form:responses_blank"));
	 forward("form/edit_question/$formpost/$index");
      }
      $same_response=false;
      $i=0;
      while(($i<$number_responses)&&(!$same_response)){
         $j=$i+1;
         while($j<$number_responses){
            if (strcmp($responsesarray[$i],$responsesarray[$j])==0){
               $same_response=true;
               break;
	    }
	    $j=$j+1;
	 }
	 $i=$i+1;
      }
      if ($same_response){
         register_error(elgg_echo("form:response_repetition"));
	 forward("form/edit_question/$formpost/$index");
      }
      if ($number_responses<2){
         register_error(elgg_echo("form:response_only_one_option"));
	 forward("form/edit_question/$formpost/$index");
      }
   }

   if (strcmp($input_response_type,"grid")==0){
      $blank_response=false;
      $responsesrowsarray=array();
      $i=0;
      foreach($responses_rows as $one_response){
         $responsesrowsarray[$i]=$one_response;
	 if (strcmp($one_response,"")==0){
            $blank_response=true;
	    break;
	 }
	 $i=$i+1;
      }	           
      if ($blank_response){
         register_error(elgg_echo("form:row_blank"));
	 forward("form/edit_question/$formpost/$index");
      }
      $same_response=false;
      $i=0;
      while(($i<$number_responses_rows)&&(!$same_response)){
         $j=$i+1;
	 while($j<$number_responses_rows){
            if (strcmp($responsesrowsarray[$i],$responsesrowsarray[$j])==0){
               $same_response=true;
	       break;
	    }
	    $j=$j+1;
         }
	 $i=$i+1;
      }
      if ($same_response){
         register_error(elgg_echo("form:row_repetition"));
	 forward("form/edit_question/$formpost/$index");
      }
      
      $blank_response=false;
      $responsescolumnsarray=array();
      $i=0;
      foreach($responses_columns as $one_response){
         $responsescolumnsarray[$i]=$one_response;
	 if (strcmp($one_response,"")==0){
            $blank_response=true;
	    break;
	 }
	 $i=$i+1;
      }	           
      if ($blank_response){
         register_error(elgg_echo("form:column_blank"));
	 forward("form/edit_question/$formpost/$index");
      }
      $same_response=false;
      $i=0;
      while(($i<$number_responses_columns)&&(!$same_response)){
         $j=$i+1;
	 while($j<$number_responses_columns){
            if (strcmp($responsescolumnsarray[$i],$responsescolumnsarray[$j])==0){
               $same_response=true;
	       break;
	    }
	    $j=$j+1;
         }
	 $i=$i+1;
      }
      if ($same_response){
         register_error(elgg_echo("form:column_repetition"));
	 forward("form/edit_question/$formpost/$index");
      }
      if ($number_responses_columns<2){
         register_error(elgg_echo("form:column_only_one_option"));
	 forward("form/edit_question/$formpost/$index");
      }	
   }	
					
   $previous_response_type = $one_question->response_type;
   if ((strcmp($previous_response_type,"radiobutton")==0)||(strcmp($previous_response_type,"checkbox")==0)){
      $previous_responses = $one_question->responses;
      $previous_responses_array = explode(Chr(26),$previous_responses);
      $previous_responses_array = array_map('trim', $previous_responses_array);
      $number_previous_responses=count($previous_responses_array);
      if ($number_responses!=$number_previous_responses){
         $modification=true;
      } 
   }
   if (strcmp($previous_response_type,"grid")==0){
      $previous_responses_rows = $one_question->responses_rows;
      $previous_responses_rows_array = explode(Chr(26),$previous_responses_rows);
      $previous_responses_rows_array = array_map('trim', $previous_responses_rows_array);
      $number_previous_responses_rows=count($previous_responses_rows_array);
      $previous_responses_columns = $one_question->responses_columns;
      $previous_responses_columns_array = explode(Chr(26),$previous_responses_columns);
      $previous_responses_columns_array = array_map('trim', $previous_responses_columns_array);
      $number_previous_responses_columns=count($previous_responses_columns_array);
      if (($number_responses_rows!=$number_previous_responses_rows)||($number_responses_columns!=$number_previous_responses_columns)){
         $modification=true;
      } 
   }
  		
   if (($count_responses>0)&&($modification)){
      register_error(elgg_echo("form:structure"));
      // Remove the form post cache
      elgg_clear_sticky_form('edit_question_form');
      forward("form/edit/$formpost/$index");
   
   } else {
     
      // Edit question
      if (!$one_question->save()){
	 register_error(elgg_echo('form:question_error_save'));
	 forward("form/edit_question/$formpost/$index");
      }
      $one_question->question = $input_question;
      if (strcmp($input_obligatory_response,"on")==0) {
         $one_question->obligatory_response=true;
      } else { 
         $one_question->obligatory_response=false;
      }
      $one_question->question_html = $input_question_html;
      if (is_array($questiontagsarray)){
         $one_question->tags = $questiontagsarray;
      }
      $one_question->response_type = $input_response_type;
      if ((strcmp($input_response_type,"radiobutton")==0)||(strcmp($input_response_type,"checkbox")==0)){
         $one_question->responses_alignment = $input_responses_alignment;
	 $one_question->responses = $input_responses;
      } else {
	 if (strcmp($input_response_type,"grid")==0){
            $one_question->responses_rows = $input_responses_rows;
            $one_question->responses_columns = $input_responses_columns;
         }
      }
      // Remove the form post cache
      elgg_clear_sticky_form('edit_question_form');

      // Add to river
      //if ($form->created)
      //   add_to_river('river/object/form/update','update',$user_guid,$formpost);
      
      // Forward
      forward("form/edit/$formpost"); 
   }
}
?>
