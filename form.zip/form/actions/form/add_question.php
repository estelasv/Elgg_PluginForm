<?php

gatekeeper();

$formpost = get_input('formpost');
$form = get_entity($formpost);

if ($form->getSubtype() == "form" && $form->canEdit()) {
   $user_guid = elgg_get_logged_in_user_guid();

   $input_question = get_input('question');
   $input_obligatory_response = get_input('obligatory_response');
   $input_question_html = get_input('question_html');
   $input_response_type = get_input('response_type');
   if ((strcmp($input_response_type,"radiobutton")==0)||(strcmp($input_response_type,"checkbox")==0)){
      $input_responses_alignment = get_input('responses_alignment');
      $responses = get_input('responses');
      $responses = array_map('trim', $responses);
      $input_responses = implode(Chr(26),$responses);
      $number_responses = count($responses);
   } elseif (strcmp($input_response_type,"grid")==0){
      $responses_rows = get_input('responses_rows');
      $responses_rows = array_map('trim', $responses_rows);
      $input_responses_rows = implode(Chr(26),$responses_rows);
      $number_responses_rows = count($responses_rows);
      $responses_columns = get_input('responses_columns');
      $responses_columns = array_map('trim', $responses_columns);
      $input_responses_columns = implode(Chr(26),$responses_columns);
      $number_responses_columns = count($responses_columns);
   }
  
   $input_question_tags = get_input('question_tags');
   //Convert string of tags into a preformatted array
   $questiontagsarray = string_to_tag_array($input_question_tags);

   $options = array('relationship' => 'form_question', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_question','limit'=>0);
   $questions=elgg_get_entities_from_relationship($options);
   if (empty($questions)) {
      $num_questions=0;
   } else {
      $num_questions=count($questions);
   }
   $index=$num_questions;

   // Cache to the session
   elgg_make_sticky_form('add_question_form');

   // Make sure the question isn't blank
   if (strcmp($input_question,"")==0) {	
      register_error(elgg_echo("form:question_blank"));
      forward("form/add_question/$formpost/$input_question_type");
   }

   // Responses
   if ((strcmp($input_response_type,"radiobutton")==0)||(strcmp($input_response_type,"checkbox")==0)){
      $blank_response=false;
      $responsesarray=array();
      $i=0;
      foreach($responses as $one_response){
         $responsesarray[$i]=$one_response;
	 if (strcmp($one_response,"")==0){
            $blank_response=true;
	    break;
	 }
	 $i=$i+1;
      }	           
      if ($blank_response){
         register_error(elgg_echo("form:responses_blank"));
	 forward("form/add_question/$formpost/$input_question_type");
      }
      $same_response=false;
      $i=0;
      while(($i<$number_responses)&&(!$same_response)){
         $j=$i+1;
	 while($j<$number_responses){
            if (strcmp($responsesarray[$i],$responsesarray[$j])==0){
               $same_response=true;
	       break;
	    }
	    $j=$j+1;
         }
	 $i=$i+1;
      }
      if ($same_response){
         register_error(elgg_echo("form:response_repetition"));
	 forward("form/add_question/$formpost/$input_question_type");
      }
      if ($number_responses<2){
         register_error(elgg_echo("form:response_only_one_option"));
         forward("form/add_question/$formpost/$input_question_type");
      }	
   }		   

   if (strcmp($input_response_type,"grid")==0){
      $blank_response=false;
      $responsesrowsarray=array();
      $i=0;
      foreach($responses_rows as $one_response){
         $responsesrowsarray[$i]=$one_response;
	 if (strcmp($one_response,"")==0){
            $blank_response=true;
	    break;
	 }
	 $i=$i+1;
      }	           
      if ($blank_response){
         register_error(elgg_echo("form:row_blank"));
	 forward("form/add_question/$formpost/$input_question_type");
      }
      $same_response=false;
      $i=0;
      while(($i<$number_responses_rows)&&(!$same_response)){
         $j=$i+1;
	 while($j<$number_responses_rows){
            if (strcmp($responsesrowsarray[$i],$responsesrowsarray[$j])==0){
               $same_response=true;
	       break;
	    }
	    $j=$j+1;
         }
	 $i=$i+1;
      }
      if ($same_response){
         register_error(elgg_echo("form:row_repetition"));
	 forward("form/add_question/$formpost/$input_question_type");
      }
      
      $blank_response=false;
      $responsescolumnsarray=array();
      $i=0;
      foreach($responses_columns as $one_response){
         $responsescolumnsarray[$i]=$one_response;
	 if (strcmp($one_response,"")==0){
            $blank_response=true;
	    break;
	 }
	 $i=$i+1;
      }	           
      if ($blank_response){
         register_error(elgg_echo("form:column_blank"));
         forward("form/add_question/$formpost/$input_question_type");
      }
      $same_response=false;
      $i=0;
      while(($i<$number_responses_columns)&&(!$same_response)){
         $j=$i+1;
	 while($j<$number_responses_columns){
            if (strcmp($responsescolumnsarray[$i],$responsescolumnsarray[$j])==0){
               $same_response=true;
	       break;
	    }
	    $j=$j+1;
         }
	 $i=$i+1;
      }
      if ($same_response){
         register_error(elgg_echo("form:column_repetition"));
	 forward("form/add_question/$formpost/$input_question_type");
      }
      if ($number_responses_columns<2){
         register_error(elgg_echo("form:column_only_one_option"));
         forward("form/add_question/$formpost/$input_question_type");
      }	
   }		   

   // Before we can set metadata, we need to save the form post
   if (!$form->save()) {
      register_error(elgg_echo("form:error_save"));
      forward("form/add_question/$formpost/$input_question_type");
   }

   //Create new question
   $question = new ElggObject();
   $question->subtype = "form_question";
   $question->owner_guid = $user_guid;
   $question->container_guid = $form->container_guid;
   $question->access_id = $form->access_id;
   if (!$question->save()){
      register_error(elgg_echo('form:question_error_save'));
      forward("form/add_question/$formpost/$input_question_type");
   }		   
   $question->question = $input_question;
   if (strcmp($input_obligatory_response,"on")==0) {
      $question->obligatory_response=true;
   } else { 
      $question->obligatory_response=false;
   }
   $question->question_html = $input_question_html;
   $question->response_type = $input_response_type;
   if ((strcmp($input_response_type,"radiobutton")==0)||(strcmp($input_response_type,"checkbox")==0)){
      $question->responses_alignment = $input_responses_alignment;
      $question->responses = $input_responses;
   } else {
      if (strcmp($input_response_type,"grid")==0){
         $question->responses_rows = $input_responses_rows;
         $question->responses_columns = $input_responses_columns;
      }
   }
  
   if (is_array($questiontagsarray)) {
      $question->tags = $questiontagsarray;
   }
   $question->index = $index;
   add_entity_relationship($form->getGUID(),'form_question',$question->getGUID());
				
   // Remove the form post cache
   elgg_clear_sticky_form('add_question_form');

   // Add to river
   //if ($form->created)
   //   add_to_river('river/object/form/update','update',$user_guid,$formpost);

   // Forward		   
   forward("form/edit/$formpost"); 
}
?>
