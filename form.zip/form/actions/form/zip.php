<?php 

$formpost = get_input('formpost');
$form = get_entity($formpost);	

if ($form) {
   $user_guid = get_input('user_guid');
   $user = get_entity($user_guid);

   set_time_limit(0);
   ini_set('memory_limit','256M');
  
   //Questions
   $options = array('relationship' => 'form_question', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_question','limit'=>0);
   $questions=elgg_get_entities_from_relationship($options);
   if (empty($questions)) {
      $num_questions=0;
   } else {
      $num_questions=count($questions);
   }

   $index=0;
   $questionsarray=array();
   while ($index<$num_questions) {
      $options = array('relationship' => 'form_question', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_question','metadata_name_value_pairs' => array('name' => 'index', 'value' => $index));
      $this_question=elgg_get_entities_from_relationship($options);
      $questionsarray[$index]=$this_question[0];
      $index=$index+1;
   }

   if (!$form->subgroups){
      $options = array('relationship' => 'form_answer', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_answer', 'order_by' => 'e.time_created desc', 'limit' => 0, 'owner_guid' => $user_guid);
   } else {
      $options = array('relationship' => 'form_answer', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_answer', 'order_by' => 'e.time_created desc', 'limit' => 0, 'container_guid' => $user_guid);
   }
   $user_responses=elgg_get_entities_from_relationship($options);
   $user_response=$user_responses[0];

   if (!empty($user_response)){
      $user_response_content_array = explode(Chr(27),$user_response->content);
      $user_response_content_array = array_map('trim', $user_response_content_array);

      $format = get_input('format', 'A4');
      $font = get_input('font', 'times');

      $html .= "<h2><p>".htmlentities($form->title,false,'UTF-8',true)."</p></h2>";
      $html .= "<p>".$form->description."</p>";
      $html .= "<br>";
      $html .= "<hr><hr><hr>";

      $name_zip = tempnam(sys_get_temp_dir(),"zip");
      $zip = new ZipArchive();
      $zip->open($name_zip,ZIPARCHIVE::OVERWRITE);
  
      $index=0;
      while ($index<$num_questions) {
         $one_question=$questionsarray[$index];
         $question_guid = $one_question->getGUID();
	 $response_type=$one_question->response_type;
	 $num_question = $index+1;
         $html .= "<h3>" . elgg_echo("form:question") . " " . $num_question . "</h3>";
         $html .= "<p>".htmlentities($one_question->question,false,'UTF-8',true)."</p><br>";
         if ($one_question->question_html!="") {
            $html .= "<p>".$one_question->question_html . "</p><br>";
         }
         $html .= "<hr>";
         $html .= "<h3>" . elgg_echo("form:response") . "</h3>";
         if (!empty($user_response)){
            if (strcmp($response_type,"text")==0) { 
               $this_response_text=$user_response_content_array[$index];
               if (strcmp($this_response_text,"not_response")!=0) {
	          $html .= "<p>".htmlentities($this_response_text,false,'UTF-8',true)."</p>";
	       }
            } elseif (strcmp($response_type,"html")==0){
               $this_response_html=$user_response_content_array[$index];
               if (strcmp($this_response_html,"not_response")!=0) {
	          $html .= "<p>".$this_response_html."</p>";
	       }
            } elseif ((strcmp($response_type,"radiobutton")==0)||(strcmp($response_type,"checkbox")==0)){ 
               $responses = $one_question->responses;
	       $responses_alignment = $one_question->responses_alignment;
               $responses_array = explode(Chr(26),$responses);
               $responses_array =  array_map('trim',$responses_array);
               if (strcmp($response_type,"checkbox")==0){
	          $html .= "<p>";
	          if (strcmp($responses_alignment,"horizontal")==0)
	             $html .= "| ";
	          if (strcmp($user_response_content_array[$index],"not_response")==0) {
                     foreach ($responses_array as $one_response) {
	                $html .= htmlentities($one_response,false,'UTF-8',true);
		        if (strcmp($responses_alignment,"horizontal")==0)
		           $html .= " | ";
	                else
		           $html .= "<br>";
	             }
		     if (strcmp($responses_alignment,"horizontal")==0)
	                $html .="<br>";
	          } else {
	             $this_responses_array = explode(Chr(26),$user_response_content_array[$index]);
                     $this_responses_array = array_map('trim', $this_responses_array);
	             foreach ($responses_array as $one_response) {
	                if (in_array($one_response,$this_responses_array)) { 
		           $html .="<b>X</b> ".htmlentities($one_response,false,'UTF-8',true);
		        } else {
		           $html .= htmlentities($one_response,false,'UTF-8',true);
		        }
		        if (strcmp($responses_alignment,"horizontal")==0)
		           $html .= " | ";
	                else
		           $html .= "<br>";
	             }
		     if (strcmp($responses_alignment,"horizontal")==0)
	             $html .="<br>";
	          }
	          $html .= "</p>";
               } else {
	          $this_responses = $user_response_content_array[$index];
	          if (strcmp($this_responses,"not_response")==0)
                     $this_responses = "";
	          $html .= "<p>";
	          if (strcmp($responses_alignment,"horizontal")==0)
	          $html .= "| ";	  
                  foreach ($responses_array as $one_response){
	             if (strcmp($one_response,$this_responses)==0) {
	                $html .="<b>X</b> ".htmlentities($one_response,false,'UTF-8',true);
	             } else {
	                $html .= htmlentities($one_response,false,'UTF-8',true);
	             } 
		     if (strcmp($responses_alignment,"horizontal")==0)
		        $html .= " | ";
	             else
		        $html .= "<br>";
                  }
	          if (strcmp($responses_alignment,"horizontal")==0)
	             $html .="<br>";
	          $html .= "</p>";
               }	 
            } elseif (strcmp($response_type,"grid")==0){
	       $this_responses_grid = "";
               $responses_rows=$one_question->responses_rows;
               $responses_rows_array = explode(Chr(26),$responses_rows);
               $responses_rows_array = array_map('trim', $responses_rows_array);
	       $responses_columns=$one_question->responses_columns;
               $responses_columns_array = explode(Chr(26),$responses_columns);
               $responses_columns_array = array_map('trim', $responses_columns_array);
	       $this_responses = explode(Chr(26),$user_response_content_array[$index]);
               $this_responses = array_map('trim', $this_responses);
               $j=0;
	       foreach ($responses_rows_array as $one_row){ 
	          $html .= "<h4><p>". htmlentities($one_row,false,'UTF-8',true) . "</p></h4>";  
	          if (strcmp($this_responses[$j],"not_response")!=0) {
	             foreach ($responses_columns_array as $one_response){
	                if (strcmp($one_response,$this_responses[$j])==0) {
	                   $html .="<p><b>X</b> ".htmlentities($one_response,false,'UTF-8',true)."</p><br>";
	                } else {
	                   $html .= "<p>".htmlentities($one_response,false,'UTF-8',true)."</p><br>";
	                }
                     }
	          } else {
	             foreach ($responses_columns_array as $one_response) {
	                $html .="<p><b>X</b> ".htmlentities($one_response,false,'UTF-8',true)."</p><br>";
	             }       
	          }
	          $j=$j+1;
               }
	       $html .= $this_responses_grid;
            } elseif (strcmp($response_type,"urls_files")==0){
               if (!$form->subgroups) {
                  $response_files = elgg_get_entities_from_relationship(array('relationship' => 'response_file_link','relationship_guid' => $question_guid,'inverse_relationship' => false,'type' => 'object','subtype' => 'form_response_file','owner_guid' => $user_guid,'limit'=>0)); 
               } else {
                  $response_files = elgg_get_entities_from_relationship(array('relationship' => 'response_file_link','relationship_guid' => $question_guid,'inverse_relationship' => false,'type' => 'object','subtype' => 'form_response_file','container_guid' => $user_guid,'limit'=>0)); 
               }
               if ((count($response_files)>0)&&(strcmp($response_files[0]->title,"")!=0)){
                  foreach($response_files as $file){
	             $html .= "<p>" . htmlentities($file->title,false,'UTF-8',true) . "</p>";
		     $file_owner = $file->getOwnerEntity();
                     $file_owner_time_created = date('Y/m/d',$file_owner->time_created);
                     $file_dir_root = elgg_get_config('dataroot');
                     //$this_filename = $file_dir_root . $file_owner_time_created . "/" . $file_owner->guid . "/" . $file->filename;
		     $this_filename = $file->getFilenameOnFilestore();
	             if (is_readable($this_filename)) {
                        $zip->addFile($this_filename,$user->username."/".$file->title);
		     } else {
                        register_error(elgg_echo("form:file_not_readable".$this_filename));
                     }
                  }    
	       }
            }
         }
         $html .= "<hr><hr>";
         $index=$index+1;
      }

      $html .= "<hr><br><br>";

      $time_created = $user_response->time_created;
      $time_updated = $user_response->answer_time;
      $friendly_date_created = date('Y/m/d',$time_created);
      $friendly_time_created = date('G:i:s',$time_created);
      $text_time_created = elgg_echo('form:response_created') . " " . $friendly_date_created . " " . elgg_echo('form:at') . " " . $friendly_time_created; 

      $html .= $text_time_created;

      if (($time_updated)&&($time_created != $time_updated)) {
         $friendly_date_updated = date('Y/m/d',$time_updated);
         $friendly_time_updated = date('G:i:s',$time_updated);
         $html .= "<br>";
         $text_time_updated = elgg_echo('form:response_updated') . " " . $friendly_date_updated . " " . elgg_echo('form:at') . " " . $friendly_time_updated; 
         $html .= $text_time_updated;
      }

      $name_pdf = tempnam(sys_get_temp_dir(),"");
      $pdf = new HTML2FPDF('P', 'mm', $format);
      $pdf->AddPage();
      $pdf->WriteHTML($html);
      $pdf->Output($name_pdf, 'F');

      if (is_readable($name_pdf)) {
         $zip->addFile($name_pdf,$user->username."/form.pdf");
      } else {
         register_error(elgg_echo("form:pdf_file_not_readable"));
      }

      $user_filename = $user->username . ".zip";

      $zip->close();
      header("Content-type: application/zip");
      header("Content-Disposition: attachment; filename=\"$user_filename\"");
      header("Content-Transfer-Encoding: binary");
      readfile($name_zip);

      unlink($name_zip);
      unlink($name_pdf);

   } else {
      register_error(elgg_echo("form:response_notfound"));
      forward($_SERVER['HTTP_REFERER']);
   }

} else {
   register_error(elgg_echo("form:notfound"));
   forward($_SERVER['HTTP_REFERER']);
}
