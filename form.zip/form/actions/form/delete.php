<?php

gatekeeper();

$formpost = get_input('guid');
$form = get_entity($formpost);
	
if ($form->getSubtype() == "form" && $form->canEdit()) {

   $container_guid = $form->container_guid;
   $container = get_entity($container_guid);
   $owner = get_entity($form->getOwnerGUID());
   $owner_guid = $owner->getGUID();

   //Delete questions 
   $options = array('relationship' => 'form_question', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_question','limit'=>0);
   $questions=elgg_get_entities_from_relationship($options);

   foreach ($questions as $one_question){
      if (strcmp($one_question->response_type,"urls_files")==0) {
         $files_response = elgg_get_entities_from_relationship(array('relationship' => 'response_file_link','relationship_guid' => $one_question->getGUID(),'inverse_relationship' => false,'type' => 'object','limit'=>0));
         foreach($files_response as $one_file){
            $deleted=$one_file->delete();
            if (!$deleted){
               register_error(elgg_echo("form:filenotdeleted"));
               forward(elgg_get_site_url() . 'form/group/' . $container_guid);
            }
         }
      }
      $deleted=$one_question->delete();
      if (!$deleted){
         register_error(elgg_echo("form:questionnotdeleted"));
         forward(elgg_get_site_url() . 'form/group/' . $container_guid);
      }
   }

   //Delete answers
   $options = array('relationship' => 'form_answer', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_answer','limit'=>0);
   $users_responses=elgg_get_entities_from_relationship($options);

   foreach($users_responses as $one_response){
      $deleted=$one_response->delete();
      if (!$deleted){
         register_error(elgg_echo("form:answernotdeleted"));
         forward(elgg_get_site_url() . 'form/group/' . $container_guid);
      }
   }


   // Delete the event created with the form (if event_manager plugin)
   if (elgg_is_active_plugin('event_manager')){
      $event_guid=$form->event_guid;
      if ($event=get_entity($event_guid)){
         $deleted=$event->delete();
         if (!$deleted){
           register_error(elgg_echo("form:eventmanagernotdeleted"));
           forward(elgg_get_site_url() . 'form/group/' . $container_guid);
         }
         else
            system_message(elgg_echo("event_manager:action:event:delete:ok"));
      }
   }

   // Delete zip
   $options = array('relationship' => 'zips_file_link', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_zips_file','limit'=>0);
   $previous_files_zips=elgg_get_entities_from_relationship($options);
   foreach($previous_files_zips as $one_file){
      $deleted=$one_file->delete();
      if (!$deleted){
         register_error(elgg_echo("form:filenotdeleted"));
	 forward(elgg_get_site_url() . 'form/group/' . $container_guid);
      }
   }

   // Delete it!
   $deleted = $form->delete();
   if ($deleted > 0) {
      system_message(elgg_echo("form:deleted"));
   } else {
      register_error(elgg_echo("form:notdeleted"));
   }
   forward(elgg_get_site_url() . 'form/group/' . $container_guid);
}	

?>