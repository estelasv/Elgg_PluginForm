<?php

gatekeeper();

$formpost = get_input('formpost');
$form = get_entity($formpost);
$edit = get_input('edit');

if ($form->getSubtype() == "form" && $form->canEdit()) {

   $form->option_close_value = 'form_not_close';   
   $form->opened = false;
   $form->action = true;

   if (elgg_is_active_plugin('event_manager')){
      $event_guid = $form->event_guid;
      if ($event = get_entity($event_guid)){
         $deleted = $event->delete();
         if (!$deleted){
            register_error(elgg_echo("form:eventmanagernotdeleted"));
            forward(elgg_get_site_url() . 'form/group/' . $container_guid);
         }
         else
            system_message(elgg_echo("event_manager:action:event:delete:ok"));
       }
    }  

   //System message 
   system_message(elgg_echo("form:closed_listing"));
   //Forward
   if (strcmp($edit,'no')==0) {
      forward($_SERVER['HTTP_REFERER']);
   } else {
      forward("form/edit/$formpost");
   }
}
		
?>
