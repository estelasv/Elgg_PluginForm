<?php

gatekeeper();

$user_guid = elgg_get_logged_in_user_guid();
$user = get_entity($user_guid);

$title = get_input('title');
$description = get_input('description');
$confirm_correct_answer = get_input('confirm_correct_answer');
$option_activate_value = get_input('option_activate_value');	
$option_close_value = get_input('option_close_value');
if (strcmp($option_activate_value,'form_activate_date')==0){
   $opendate = get_input('opendate');
   $opentime = get_input('opentime');
}
if (strcmp($option_close_value,'form_close_date')==0){
   $closedate = get_input('closedate');
   $closetime = get_input('closetime');
}
//$visibility = get_input('visibility');
$subgroups = get_input('subgroups');
$tags = get_input('formtags');
$access_id = get_input('access_id'); 
$container_guid = get_input('container_guid');
$container = get_entity($container_guid);

// Cache to the session
elgg_make_sticky_form('add_form');

//////////////////////////////////////////////////////////////////////////

//Times

if (strcmp($option_activate_value,'form_activate_date')==0){
   $mask_time="[0-2][0-9]:[0-5][0-9]";
   if (!ereg($mask_time,$opentime,$same)){
	register_error(elgg_echo("form:bad_times"));
	forward($_SERVER['HTTP_REFERER']);
   }
}
if (strcmp($option_close_value,'form_close_date')==0){
   $mask_time="[0-2][0-9]:[0-5][0-9]";
   if (!ereg($mask_time,$closetime,$same)){
	register_error(elgg_echo("form:bad_times"));
	forward($_SERVER['HTTP_REFERER']);
   }
}
$now=time();
if (strcmp($option_activate_value,'form_activate_now')==0){
   $activate_time=$now;
} else {
   $opentime_array = explode(':',$opentime);
   $opentime_h = trim($opentime_array[0]);
   $opentime_m = trim($opentime_array[1]);
   $opendate_text = date("Y-m-d",$opendate);
   $opendate = strtotime($opendate_text." ".date_default_timezone_get());
   $opendate_array = explode('-',$opendate_text);
   $opendate_y = trim($opendate_array[0]);
   $opendate_m = trim($opendate_array[1]);
   $opendate_d = trim($opendate_array[2]);
   $activate_date = mktime(0,0,0,$opendate_m,$opendate_d,$opendate_y);
   $activate_time = mktime($opentime_h,$opentime_m,0,$opendate_m,$opendate_d,$opendate_y);

   if ($activate_time < 1){
      register_error(elgg_echo("form:bad_times"));
      forward($_SERVER['HTTP_REFERER']);
   }
}

if (strcmp($option_close_value,'form_not_close')==0){
   $close_time=$now+1;
} else {
   $closetime_array = explode(':',$closetime);
   $closetime_h = trim($closetime_array[0]);
   $closetime_m = trim($closetime_array[1]);
   $closedate_text = date("Y-m-d",$closedate);
   $closedate = strtotime($closedate_text." ".date_default_timezone_get());
   $closedate_array = explode('-',$closedate_text);
   $closedate_y = trim($closedate_array[0]);
   $closedate_m = trim($closedate_array[1]);
   $closedate_d = trim($closedate_array[2]);
   $close_date = mktime(0,0,0,$closedate_m,$closedate_d,$closedate_y);
   $close_time = mktime($closetime_h,$closetime_m,0,$closedate_m,$closedate_d,$closedate_y);
 
   if ($close_time < 1){
      register_error(elgg_echo("form:bad_times"));
      forward($_SERVER['HTTP_REFERER']);
   }
}
if ($activate_time>=$close_time) {
   register_error(elgg_echo("form:error_times"));
   forward($_SERVER['HTTP_REFERER']);
}

//////////////////////////////////////////////////////////////////////////

// Convert string of tags into a preformatted array
$tagarray = string_to_tag_array($tags);

// Make sure the title and description aren't blank
if ((strcmp($title,"")==0) || (strcmp($description,"")==0)) {
	register_error(elgg_echo("form:blank"));
	forward($_SERVER['HTTP_REFERER']);
} 

// Initialise a new ElggObject
$form = new ElggObject();

// Tell the system it's a form post
$form->subtype = "form";

// Set its owner, container and group
$form->owner_guid = $user_guid;
$form->container_guid = $container_guid;
$form->group_guid = $container_guid;

// Set its access
$form->access_id = $access_id;

// Set its title 
$form->title = $title; 

// Set its description
$form->description = $description;

// Set send confirmation of correct answer
$form->confirm_correct_answer = $confirm_correct_answer;

// Set created	
$form->created=false;

// Save the form post
if (!$form->save()) {
   register_error(elgg_echo("form:error_save"));
   forward($_SERVER['HTTP_REFERER']);
}

$formpost=$form->getGUID();

// Set times
$form->option_activate_value = $option_activate_value;
$form->option_close_value = $option_close_value;
if (strcmp($option_activate_value,'form_activate_now')!=0){
   $form->activate_date = $activate_date;
   $form->activate_time = $activate_time;
   $form->form_activate_date = $activate_date;
   $form->form_activate_time = $opentime;
}
if (strcmp($option_close_value,'form_not_close')!=0){
   $form->close_date = $close_date;
   $form->close_time = $close_time;
   $form->form_close_date = $close_date;
   $form->form_close_time = $closetime;
}
$form->option_close_value = 'form_not_close';
$form->opened = false;

// Set evaluators
$form->evaluators = "teachers";

// Set visibility
//if (strcmp($visibility,"on")==0) {
//   $form->visibility=true;
//} else { 
//   $form->visibility=false;
//}

// Set subgroups
if (strcmp($subgroups,"on")==0) {
   $form->subgroups=true;
   $form->who_answers='subgroup';
} else { 
   $form->subgroups=false;
   $form->who_answers='member';
}

// Now let's add tags.
if (is_array($tagarray)) {
   $form->tags = $tagarray;
}

// Remove the form post cache
elgg_clear_sticky_form('add_form');

// Forward
forward("form/add_question/$formpost"); 

?>