<?php

gatekeeper();

$formpost = get_input('formpost');
$form = get_entity($formpost);

if ($form->getSubtype() == "form" && $form->canEdit()) {

   if ($form->visibility) {
      $form->visibility = false;
   } else {
      $form->visibility = true;
   }

   $container_guid = $form->container_guid; 
   $container = get_entity($container_guid);

   //Change access_id in answers
   $options = array('relationship' => 'form_answer', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_answer','limit'=>0);
   $users_responses=elgg_get_entities_from_relationship($options);
   foreach($users_responses as $one_response){
      if ($form->subgroups) {
         $response_subgroup_guid = $one_response->container_guid;
	 $response_subgroup = get_entity($response_subgroup_guid);
      }
      if (!$form->visibility){
	 //compañeros y profesores
	 if ($form->subgroups)
	    $one_response->access_id = $response_subgroup->teachers_acl;
	 else   
	    $one_response->access_id = $container->teachers_acl;
      } else {
	 $one_response->access_id = $form->access_id;
      }
      if (!$one_response->save()) {
         register_error(elgg_echo('form:answer_error_save'));
         forward($_SERVER['HTTP_REFERER']);
      }
   }
   //Change access_id in files
   $options = array('relationship' => 'form_question', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_question','limit'=>0);
   $questions=elgg_get_entities_from_relationship($options);
   foreach ($questions as $one_question){
      $files_response = elgg_get_entities_from_relationship(array('relationship' => 'response_file_link','relationship_guid' => $one_question->getGUID(),'inverse_relationship' => false,'type' => 'object','limit'=>0));
      foreach($files_response as $one_file){
         if ($form->subgroups) {
            $file_subgroup_guid = $one_file->container_guid;
            $file_subgroup = get_entity($file_subgroup_guid);
         }
         if (!$form->visibility){
            //compañeros y profesores
            if ($form->subgroups)
               $one_file->access_id = $file_subgroup->teachers_acl;
            else   
               $one_file->access_id = $container->teachers_acl;
         } else {
            $one_file->access_id = $form->access_id;
         }
         if (!$one_file->save()) {
            register_error(elgg_echo('form:file_error_save'));
            forward($_SERVER['HTTP_REFERER']);
         }
      }
   }

   //Forward
   forward($_SERVER['HTTP_REFERER']);
}
		
?>
