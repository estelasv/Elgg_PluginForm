<?php

gatekeeper();

// Get input data
$formpost = get_input('formpost');
$index = get_input('index');	

$user_guid = elgg_get_logged_in_user_guid();

$form = get_entity($formpost);
$container = get_entity($form->container_guid);

if ($form->getSubtype() == "form" && $form->canEdit()) {

   $count_responses=$form->countAnnotations('all_responses');
  
   if ($count_responses>0){   
      register_error(elgg_echo("form:structure"));
      forward("form/edit/$formpost");
   } 

   $options = array('relationship' => 'form_question', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_question','limit'=>0);
   $questions=elgg_get_entities_from_relationship($options);
   $num_questions=count($questions);

   $already_deleted=false;
   foreach ($questions as $one_question){
      if ($one_question->index==$index){
         if (!$already_deleted){
            $already_deleted=true;
	    $deleted=$one_question->delete();
            if (!$deleted){
               register_error(elgg_echo("form:questionnotdeleted"));
	       forward("form/edit/$formpost");
            }
	 }
      } else {
	 $previous_index = $one_question->index;
	 if ($previous_index>$index){
            $one_question->index = $previous_index-1;
	 }
      }
   }
    
   // System message
   system_message(elgg_echo("form:updated"));
   
   //Forward
   forward("form/edit/$formpost");
}

?>