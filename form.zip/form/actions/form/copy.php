<?php

gatekeeper();

$formpost = get_input('formpost');
$form = get_entity($formpost);
$container_guid = get_input('container_guid');

$user_guid = elgg_get_logged_in_user_guid();

if ($form->getSubtype() == "form" && $form->canEdit()) {

   // Initialise a new ElggObject
   $new_form = new ElggObject();

   // Tell the system it's a form post
   $new_form->subtype = "form";

   // Set its owner, container and group
   $new_form->owner_guid = $user_guid;
   $new_form->container_guid = $container_guid;
   $new_form->group_guid = $container_guid;

   // Set its access
   $new_form->access_id = $form->access_id;

   // Set its title 
   $new_form->title = $form->title . elgg_echo("form:one_copy");

   // Set its description
   $new_form->description = $form->description;

   // Set created	
   $new_form->created=false;

   // Save the form post
   if (!$new_form->save()) {
      register_error(elgg_echo("form:error_save"));
      forward($_SERVER['HTTP_REFERER']);
   }

   // Set times
   $new_form->option_activate_value = $form->option_activate_value;
   $new_form->option_close_value = $form->option_close_value;
   if (strcmp($form->option_activate_value,'form_activate_now')!=0){
      $new_form->activate_date = $form->activate_date;
      $new_form->activate_time = $form->activate_time;
      $new_form->form_activate_date = $form->activate_date;
      $new_form->form_activate_time = $form->opentime;
   }
   if (strcmp($form->option_close_value,'form_not_close')!=0){
      $new_form->close_date = $form->close_date;
      $new_form->close_time = $form->close_time;
      $new_form->form_close_date = $form->close_date;
      $new_form->form_close_time = $form->closetime;
   }
   $new_form->opened = $form->opended;

   // Set evaluators
   $new_form->evaluators = $form->evaluators;

   // Set visibility
   //$new_form->visibility=$form->visibility;

   // Set subgroups
   $new_form->subgroups=$form->subgroups;
   $new_form->who_answers=$form->who_answers;

   // Add tags                  
   $tagsarray=array();
   if(is_array($form->tags)){
      $i=0;
      foreach($form->tags as $one_tag){
         $tagsarray[$i] = $form->tags[$i];
         $i=$i+1;
      }
   } else {
      $tagsarray[0]=$form->tags;
   }    
   $new_form->tags = array();
   $new_form->tags = $tagsarray;

   //Questions

   $options = array('relationship' => 'form_question', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_question','limit'=>0);
   $questions=elgg_get_entities_from_relationship($options);

   foreach ($questions as $one_question){
      $new_question = new ElggObject();
      $new_question->subtype = "form_question";
      $new_question->owner_guid = $user_guid;
      $new_question->container_guid = $container_guid;
      $new_question->access_id = $one_question->access_id;
      if (!$new_question->save()){
         register_error(elgg_echo('form:question_error_save'));
         forward($_SERVER['HTTP_REFERER']);
      }               
      $new_question->question = $one_question->question;
      $new_question->obligatory_response = $one_question->obligatory_response;
      $new_question->question_html = $one_question->question_html;
      $new_question->response_type = $one_question->response_type;
      if ((strcmp($one_question->response_type,"radiobutton")==0)||(strcmp($one_question->response_type,"checkbox")==0)){
         $new_question->responses_alignment = $one_question->responses_alignment;
         $new_question->responses = $one_question->responses;
      } else {
         if (strcmp($one_question->response_type,"grid")==0){
            $new_question->responses_rows = $one_question->responses_rows;
            $new_question->responses_columns = $one_question->responses_columns;
         }
      }

      $tagsarray=array();
      if(is_array($one_question->tags)){
         $i=0;
         foreach($one_question->tags as $one_tag){
            $tagsarray[$i] = $one_question->tags[$i];
            $i=$i+1;
         }
      } else {
         $tagsarray[0]=$one_question->tags;
      }    
      $new_question->tags = array();
      $new_question->tags = $tagsarray;

      if (is_array($questiontagsarray)) {
         $new_question->tags = $questiontagsarray;
      }
      $new_question->index = $one_question->index;

      add_entity_relationship($new_form->getGUID(),'form_question',$new_question->getGUID());
   }

   //System message 
   system_message(elgg_echo("form:copied"));
   
   //Forward
   forward($_SERVER['HTTP_REFERER']);
  
}
		
?>
