<?php

gatekeeper();

// Get input data
$formpost = get_input('formpost');
$index = get_input('index');	
$action = get_input('ac');

$user_guid = get_loggedin_userid();
	
$form = get_entity($formpost);
$container = get_entity($form->container_guid);

if ($form->getSubtype() == "form" && $form->canEdit()) {
 
   $count_responses=$form->countAnnotations('all_responses');
   if ($count_responses>0){   
        register_error(elgg_echo("form:structure"));
	forward("form/edit/$formpost"); 
   } 

   $options = array('relationship' => 'form_question', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_question','limit' => 0, 'order_by_metadata' => array('name' => 'index', 'direction' => 'asc','as'=>'integer'));
   $questions=elgg_get_entities_from_relationship($options);
   $num_questions=count($questions);
 
   $end=0;
   if (strcmp($action,"up")==0){
      foreach ($questions as $one_question){
         if ($one_question->index==$index){
            $one_question->index=$index-1;
	    $end=$end+1;
	 } else if ($one_question->index==($index-1)){
            $one_question->index=$index;
	    $end=$end+1;
         }
         if ($end==2)
            break;  
      }
   }

   if (strcmp($action,"down")==0){
      foreach ($questions as $one_question){ 
         if ($one_question->index==$index){
	    $one_question->index=$index+1;
	    $end=$end+1;
         } else if ($one_question->index==($index+1)){
            $one_question->index=$index;
            $end=$end+1;
         }
         if ($end==2)
            break;  
      }
   }

   if (strcmp($action,"top")==0){
      foreach ($questions as $one_question){
         if ($one_question->index==$index){
	    $one_question->index=0;
         } else {
	    if ($one_question->index < $index)
	       $one_question->index=$one_question->index+1;
         }
      }
   }

   if (strcmp($action,"bottom")==0){
      foreach ($questions as $one_question){
         if ($one_question->index==$index){
            $one_question->index=$num_questions-1;
         } else {
	    if ($one_question->index > $index)
	       $one_question->index=$one_question->index-1;
         }
      }
   }  
   // System message        
   system_message(elgg_echo("form:updated"));
   
   //Forward
   forward("form/edit/$formpost"); 
}

?>