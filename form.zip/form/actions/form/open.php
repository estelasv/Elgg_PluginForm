<?php

gatekeeper();

$formpost = get_input('formpost');
$form = get_entity($formpost);

if ($form->getSubtype() == "form" && $form->canEdit()) {

   $options = array('relationship' => 'form_question', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_question','limit'=>0);
   $questions=elgg_get_entities_from_relationship($options);
   if (empty($questions)) {
      $num_questions = 0;
   } else {
      $num_questions = count($questions);
   }

   //Not questions
   if ($num_questions==0){
      register_error(elgg_echo("form:not_questions"));
      forward("form/edit/$formpost");
   }

   $form->option_activate_value = 'form_activate_now';
   $form->opened = true;
   $form->action = true;

  //Event using the event_manager plugin if it is active
   if (elgg_is_active_plugin('event_manager') && strcmp($form->option_close_value,'form_not_close')!=0){
      $event_guid = $form->event_guid;
      if (!($event=get_entity($event_guid))){
         $newEvent = true;
         $event = new Event();
      } 

      $event->title = sprintf(elgg_echo("form:event_manager_title"),$form->title);
      $event->description = $form->input_question_html;
      $event->container_guid = $form->container_guid;
      $event->access_id = $form->access_id;
      $event->save();
   
      $event->tags = string_to_tag_array($tags);
      if ($newEvent) {
         // add event create river event
         elgg_create_river_item(array(
            'view'=> 'river/object/event/create',
            'action_type'=> 'create',
            'subject_guid'=> elgg_get_logged_in_user_guid(),
            'object_guid'=> $event->getGUID()
         ));
      }
   
      $event->comments_on = 0;
      $event->show_attendees = 0;
      $event->max_attendees = "";
      if (strcmp($form->option_activate_value,'form_activate_now')==0){
         $opentime_array = explode(':',date("H:i"));
         $opentime_h = trim($opentime_array[0]);
         $opentime_m = trim($opentime_array[1]);
         $opendate_array = explode('-',date("Y-m-d"));
         $opendate_y = trim($opendate_array[0]);
         $opendate_m = trim($opendate_array[1]);
         $opendate_d = trim($opendate_array[2]);
         $activate_date = mktime(0,0,0,$opendate_m,$opendate_d,$opendate_y);
         $activate_time = mktime($opentime_h,$opentime_m,0,$opendate_m,$opendate_d,$opendate_y);
      }
      else{
         $activate_date = $form->activate_date;
         $activate_time = $form->activate_time;
      }
      $event->start_day = $form->close_date;
      $event->start_time = $form->close_time;
      $event->end_ts = $form->close_time +1;
      
      $event->organizer = elgg_get_logged_in_user_entity()->getDisplayName();
      $event->setAccessToOwningObjects($access_id);

      // Save it, if it is new
      if (!get_entity($event_guid)){         
         if ($event->save()){
            $event_guid = $event->getGUID();
            $form->event_guid = $event_guid;
            system_message(elgg_echo("event_manager:action:event:edit:ok"));
         }
         else
            register_error(elgg_echo("form:event_manager_error_save"));
      }   }

   //System message 
   system_message(elgg_echo("form:opened_listing"));
   //Forward
   forward($_SERVER['HTTP_REFERER']);
}
		
?>
