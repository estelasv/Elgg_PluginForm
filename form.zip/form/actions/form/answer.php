<?php

gatekeeper();

//Get the form entity
$formpost = get_input('formpost');
$form = get_entity($formpost);

if ($form){
   if ($form->getSubtype() == "form") {
      $now = time();
      if (form_check_status($form)){
         $container_guid  = $form->container_guid;
         $container = get_entity($container_guid);
         $user_guid = get_input('user_guid');
         $user = get_entity($user_guid);

         if ($form->subgroups){
            $user_subgroup = elgg_get_entities_from_relationship(array('type_subtype_pairs' => array('group' => 'lbr_subgroup'),'container_guids' => $container_guid,'relationship' => 'member','inverse_relationship' => false,'relationship_guid' => $user_guid));
            $user_subgroup=$user_subgroup[0];
            $user_subgroup_guid=$user_subgroup->getGUID();
         }

         //Answers
         if (!$form->subgroups) {
            $options = array('relationship' => 'form_answer', 'relationship_guid' => $form->getGUID(),'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_answer', 'order_by' => 'e.time_created desc', 'limit' => 0, 'owner_guid' => $user_guid);
         } else {
            $options = array('relationship' => 'form_answer', 'relationship_guid' => $form->getGUID(),'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_answer', 'order_by' => 'e.time_created desc', 'limit' => 0, 'container_guid' => $user_subgroup_guid);
         }
         $user_responses=elgg_get_entities_from_relationship($options);
         if (!empty($user_responses)){
            $user_response=$user_responses[0];
         } else {
            $user_response="";
         }

         //Questions
         $options = array('relationship' => 'form_question', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_question','limit'=>0);
         $questions=elgg_get_entities_from_relationship($options);
         if (empty($questions)) {
            $num_questions=0;
         } else {
            $num_questions=count($questions);
         }

         // Cache to the session
         elgg_make_sticky_form('answer_form');

         //Each question

         $index=0;
         $content_fields = "";
         while ($index<$num_questions) {

            $options = array('relationship' => 'form_question', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_question', 'metadata_name_value_pairs' => array('name' => 'index', 'value' => $index));
            $this_question=elgg_get_entities_from_relationship($options);

            $one_question=$this_question[0];

            $question_guid=$one_question->getGUID();
            $response_type=$one_question->response_type;
            if ((strcmp($response_type,"radiobutton")==0)||(strcmp($response_type,"checkbox")==0)){
               $responses=$one_question->responses;
            } else {
   	    if (strcmp($response_type,"grid")==0){
                  $responses_rows=$one_question->responses_rows;
   	       $responses_rows_array=explode(Chr(26),$responses_rows);
   	       $responses_rows_array=array_map('trim',$responses_rows_array);
   	       $responses_columns=$one_question->responses_columns;
   	    }
            }

            //Response
            if ((strcmp($response_type,"text")==0)||(strcmp($response_type,"html")==0)||(strcmp($response_type,"radiobutton")==0)||(strcmp($response_type,"checkbox")==0)){
   	    $name_response="response_".$index;
   	    $response=get_input($name_response);
            }

            if (strcmp($response_type,"grid")==0) {
         	    $j=0;
   	    $response="";
   	    $all_responses=true;
   	    foreach($responses_rows_array as $one_row){
   	       $name_response="grid_response_".$index."_".$j;
   	       $one_response = get_input($name_response);
   	       if (empty($one_response)) {
   	          $one_response = "not_response";
   		  if ($all_responses)
   		     $all_responses = false;
   	       }
   	       if ($j==0) {
   	          $response .= $one_response;
   	       } else {
   	          $response .= Chr(26) . $one_response;
   	       }
   	       $j=$j+1;
   	    }
            }

            if (strcmp($response_type,"urls_files")==0) {
               $name_response="response_urls_".$index;
               $response_urls = get_input($name_response);
               $response_urls = array_map('trim',$response_urls);
               $name_response_names="response_urls_names_".$index;
               $response_urls_names = get_input($name_response_names);
               $response_urls_names = array_map('trim',$response_urls_names);
               $url_failed=false;
               if ((count($response_urls)>0)&&(strcmp($response_urls[0],"")!=0)) {
                  foreach ($response_urls as $one_url){
                     $xss_form = "<a rel=\"nofollow\" href=\"$one_url\" target=\"_blank\">$one_url</a>";
                     if ($xss_form != filter_tags($xss_form)) {
                        $url_failed=true;
                        break;
                     }
                  }
   	       $i=0;
                  $comp_response_urls = "";
                  foreach($response_urls as $one_url){
                     if ($i!=0)
                        $comp_response_urls .= Chr(26);
                     if ($response_urls_names[$i]!="")
                        $comp_response_urls .= $response_urls_names[$i] . Chr(24) . $response_urls[$i];
                     else
                        $comp_response_urls .= $response_urls[$i] . Chr(24) . $response_urls[$i];
                     $i=$i+1;
                  }
                  $response = $comp_response_urls;
               } else {
                  $response = "";
               }
               if ($url_failed) {
                  register_error(elgg_echo('form:url_failed'));
                  forward($_SERVER['HTTP_REFERER']);
               }
            }

            if ((strcmp($response_type,"radiobutton")==0)||(strcmp($response_type,"checkbox")==0)){
   	    if (!empty($response)){
   	       if (is_array($response)){
   	          $this_response = "";
   		  $first=true;
   		  foreach($response as $one_response){
   		     if ($first){
   		        $first=false;
   	                $this_response .= $one_response;
   		     } else {
   		        $this_response .= Chr(26) . $one_response;
   		     }
   	          }
   	       } else {
   	          $this_response = $response;
   	       }
   	    } else {
   	       $this_response = "not_response";
   	    }
   	 }

   	 if (strcmp($response_type,"grid")==0){
   	    $this_response = $response;
   	 }

            if ((strcmp($response_type,"text")==0)||(strcmp($response_type,"html")==0)||(strcmp($response_type,"urls_files")==0)){
               if (strcmp($response,"")!=0){
   	       $this_response = $response;
   	    } else {
   	       $this_response = "not_response";
   	    }
   	 }

            if (strcmp($content_fields,"")!=0) {
   	    $content_fields .= Chr(27) . $this_response;
   	 } else {
   	    $content_fields .= $this_response;
            }

   	 $j=0;
            $file_save_well=true;
            $file_response_guid=array();
   	 $name_upload = 'upload_response_file_'.$index;
            $file_response_counter = count($_FILES[$name_upload]['name']);
   	 $file_response_guids = "";
            if ((strcmp($response_type,"urls_files")==0)&&($file_response_counter>0)&&($_FILES[$name_upload]['name'][0] != "")){
               for($k=0; $k<$file_response_counter; $k++){
                  $file_response[$k] = new ResponsesFormPluginFile();
                  $file_response[$k]->subtype = "form_response_file";
                  $prefix = "file/";
                  $filestorename = elgg_strtolower(time().$_FILES[$name_upload]['name'][$k]);
                  $file_response[$k]->setFilename($prefix.$filestorename);
                  $file_response[$k]->setMimeType($_FILES[$name_upload]['type'][$k]);
                  $file_response[$k]->originalfilename = $_FILES[$name_upload]['name'][$k];
                  $file_response[$k]->simpletype = elgg_get_file_simple_type($_FILES[$name_upload]['type'][$k]);
                  $file_response[$k]->open("write");
                  if (isset($_FILES[$name_upload]) && isset($_FILES[$name_upload]['error'][$k])) {
                     $uploaded_file = file_get_contents($_FILES[$name_upload]['tmp_name'][$k]);
                  } else {
                     $uploaded_file = false;
                  }
                  $file_response[$k]->write($uploaded_file);
                  $file_response[$k]->close();
                  $file_response[$k]->title = $_FILES[$name_upload]['name'][$k];
   	       //if (!$form->visibility) {
   	          if ($form->subgroups){
   	             $file_response[$k]->access_id = $user_subgroup->teachers_acl;
   	          } else {
   	             $file_response[$k]->access_id = $container->teachers_acl;
   	          }
   	       //} else {
   	       //   $file_response[$k]->access_id = $form->access_id;
   	       //}
                  if ($form->subgroups) {
                     $file_response[$k]->container_guid = $user_subgroup_guid;
                  } else {
                     $file_response[$k]->container_guid = $container_guid;
                  }
                  $file_response[$k]->owner_guid = $user_guid;
                  $file_response_save = $file_response[$k]->save();
                  if (!$file_response_save) {
                     $file_save_well=false;
                     break;
                  } else {
                     $file_response_guid[$j] = $file_response[$k]->getGUID();
                     if ($k==0)
                        $file_response_guids .= $file_response[$k]->getGUID();
                     else
                        $file_response_guids .= "," . $file_response[$k]->getGUID();
                     $j=$j+1;
                  }
               }
            }

            if (!$file_save_well){
               foreach($file_response_guid as $one_file_guid){
                  $one_file=get_entity($one_file_guid);
                  $deleted=$one_file->delete();
                  if (!$deleted){
                     register_error(elgg_echo('form:filenotdeleted'));
                     forward($_SERVER['HTTP_REFERER']);
                  }
               }
               register_error(elgg_echo('form:file_error_save'));
               forward($_SERVER['HTTP_REFERER']);
            }
   	 if (!$form->subgroups) {
               $previous_response_files = elgg_get_entities_from_relationship(array('relationship' => 'response_file_link','relationship_guid' => $question_guid,'inverse_relationship' => false,'type' => 'object','subtype' => 'form_response_file','owner_guid'=>$user_guid,'limit'=>0));
            } else {
               $previous_response_files = elgg_get_entities_from_relationship(array('relationship' => 'response_file_link','relationship_guid' => $question_guid,'inverse_relationship' => false,'type' => 'object','subtype' => 'form_response_file','container_guid'=>$user_subgroup_guid,'limit'=>0));
            }
   	 if (empty($previous_response_files)) {
   	    $count_previous_response_files = 0;
   	 } else {
   	    $count_previous_response_files = count($previous_response_files);
            }
   	 foreach($previous_response_files as $one_file){
               $value = get_input($one_file->getGUID());
               if($value == '1'){
                  $file1 = get_entity($one_file->getGUID());
                  $deleted=$file1->delete();
                  if (!$deleted){
                     register_error(elgg_echo('form:filenotdeleted'));
                     forward($_SERVER['HTTP_REFERER']);
                  }
   	       $count_previous_response_files = $count_previous_response_files-1;
               }
            }
   	 $file_response_guids_array=explode(",",$file_response_guids);
            foreach($file_response_guids_array as $one_file_guid){
               add_entity_relationship($question_guid,'response_file_link',$one_file_guid);
            }

   	 if ((((strcmp($response_type,"text")==0)||(strcmp($response_type,"html")==0)||(strcmp($response_type,"radiobutton")==0)||(strcmp($response_type,"checkbox")==0))&&(strcmp($this_response,"not_response")==0))||((strcmp($response_type,"grid")==0)&&(!$all_responses))||((strcmp($response_type,"urls_files")==0)&&(strcmp($this_response,"not_response")==0)&&($count_previous_response_files==0)&&(($file_response_counter==0)||(($file_response_counter>0)&&($_FILES[$name_upload]['name'][0] == ""))))) {
   	    if ($one_question->obligatory_response) {
   	       register_error(elgg_echo('form:response_obligatory_error'));
                  forward($_SERVER['HTTP_REFERER']);
   	    }
   	 }
   	 $index = $index+1;
         }

         $found=false;
         if (!empty($user_response)) {
            $user_response->content=$content_fields;
   	 $user_response->answer_time=$now;
   	 $found=true;
   	 $answer_url = form_answer_url($user_response);
         }

         if (!$found){
            // Initialise a new ElggObject to be the answer
   	 $answer = new ElggObject();
   	 $answer->subtype = "form_answer";
   	 $answer->owner_guid = $user_guid;
   	 //if (!$form->visibility) {
   	    if ($form->subgroups){
   	       $answer->access_id = $user_subgroup->teachers_acl;
   	    } else {
   	       $answer->access_id = $container->teachers_acl;
   	    }
   	 //} else {
   	 //   $answer->access_id = $form->access_id;
   	 //}
   	 if ($form->subgroups){
   	    $answer->container_guid = $user_subgroup_guid;
   	    $answer->who_answers = 'subgroup';
   	 } else {
   	    $answer->container_guid = $container_guid;
   	    $answer->who_answers = 'member';
   	 }

   	 if (!$answer->save()){
   	    register_error(elgg_echo("form:answer_save_error"));
   	    forward($_SERVER['HTTP_REFERER']);
   	 }
   	 $answer->answer_time = $now;
   	 $answer->content = $content_fields;
     add_entity_relationship($formpost,'form_answer',$answer->getGUID());
   	 $answer_url = form_answer_url($answer);
            $form->annotate('all_responses', "1", $form->access_id);
         }

         //Nofity correct answer
         if ($form->confirm_correct_answer) {
            $site_guid = elgg_get_config('site_guid');
            $site = get_entity($site_guid);
            $sitename = $site->name;
            $group = $container;
            $groupname = $container->name;
            $link = $answer_url;
            $title = $form->title;
            $subject = sprintf(elgg_echo('form:correct_answer:email:subject'),$title,$sitename,$groupname);
            $body = sprintf(elgg_echo('form:correct_answer:email:body'),$title,$sitename,$groupname,$link);
            notify_user($user_guid,$form->owner_guid,$subject,$body, array('action'=> 'create', 'object'=> $answer));
         }

         // Remove the form post cache
         elgg_clear_sticky_form('answer_form');

         // System message
         system_message(elgg_echo("form:answered"));

         // Forward to the forms listing page
         forward(elgg_get_site_url() . 'form/group/' . $container_guid);

      } else {
         system_message(elgg_echo("form:closed"));
         forward($_SERVER['HTTP_REFERER']);
      }
   }
}
else{
   system_message(elgg_echo("form:no_object"));
}

?>
