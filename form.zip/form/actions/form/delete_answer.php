<?php

gatekeeper();

$formpost = get_input('formpost');
$form = get_entity($formpost);

if ($form->getSubtype() == "form") {
   $user_guid = get_input('user_guid');
   $user = get_entity($user_guid);
   
   $opened = form_check_status($form); 

   if ($opened) {
      //Files
      $options = array('relationship' => 'form_question', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_question','limit'=>0);
      $questions=elgg_get_entities_from_relationship($options);
      foreach ($questions as $one_question){
         if (strcmp($one_question->response_type,"urls_files")==0) {
            if (!$form->subgroups) {
               $files_response = elgg_get_entities_from_relationship(array('relationship' => 'response_file_link','relationship_guid' => $one_question->getGUID(),'inverse_relationship' => false,'type' => 'object','subtype' => 'form_response_file','user_guid'=>$user_guid,'limit'=>0));
	    } else {
	       $files_response = elgg_get_entities_from_relationship(array('relationship' => 'response_file_link','relationship_guid' => $one_question->getGUID(),'inverse_relationship' => false,'type' => 'object','subtype' => 'form_response_file','container_guid'=>$user_guid,'limit'=>0));
	    }
            foreach($files_response as $one_file){
               $deleted=$one_file->delete();
               if (!$deleted){
                  register_error(elgg_echo("form:filenotdeleted"));
                  forward($_SERVER['HTTP_REFERER']);
               }
            }
	 }
      }
      //Answer
      if (!$form->subgroups){
         $options = array('relationship' => 'form_answer', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_answer', 'order_by' => 'e.time_created desc', 'limit' => 0, 'owner_guid' => $user_guid);
      } else {
         $options = array('relationship' => 'form_answer', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_answer', 'order_by' => 'e.time_created desc', 'limit' => 0, 'container_guid' => $user_guid);
      }
      $user_responses=elgg_get_entities_from_relationship($options);
      if (!empty($user_responses)){
         $user_response=$user_responses[0];
         $deleted=$user_response->delete();
         if (!$deleted){
	    register_error(elgg_echo("form:answernotdeleted"));
	    forward($_SERVER['HTTP_REFERER']);
         }
         //System message
         system_message(elgg_echo("form:answerdeleted"));
      }
   }
    //Forward
   forward($_SERVER['HTTP_REFERER']);
}

?>
