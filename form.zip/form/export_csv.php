<?php

require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

$filename = "forms.csv";
header("Content-Type: text/csv; charset=utf-8; header=present");
header("Content-Disposition: attachment; filename=\"$filename\"");

set_time_limit(0);

$formpost=get_input('formpost');
$form = get_entity($formpost);
$user_guid = elgg_get_logged_in_user_guid();
$container = get_entity($form->container_guid);

$owner = $form->getOwnerEntity();
$owner_guid = $owner->getGUID();
$group_guid=$container->guid;
$group = get_entity($group_guid);
$group_owner_guid = $group->owner_guid;         

//Questions
$options = array('relationship' => 'form_question', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_question','limit'=>0);
$questions=elgg_get_entities_from_relationship($options);
if (empty($questions)) {
   $num_questions=0;
} else {
   $num_questions=count($questions);
}

$index=0;
$questionsarray=array();
while ($index<$num_questions) {
   $options = array('relationship' => 'form_question', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_question','metadata_name_value_pairs' => array('name' => 'index', 'value' => $index));
   $this_question=elgg_get_entities_from_relationship($options);
   $questionsarray[$index]=$this_question[0];
   $index=$index+1;
}

if (!$form->subgroups){
   $members = $group->getMembers(false);
} else {
   $members=elgg_get_entities(array('type_subtype_pairs' => array('group' => 'lbr_subgroup'),'limit' => 0,'container_guids' => $group_guid));
}

$i=0;
$membersarray=array();
foreach ($members as $member){
   $member_guid=$member->getGUID();
   if (($member_guid!=$owner_guid)&&($group_owner_guid!=$member_guid)&&(!check_entity_relationship($member_guid,'group_admin',$group_guid))){
      $membersarray[$i]=$member_guid;
      $i=$i+1;
   }
}

$row = '""';
$index=0;
while ($index<$num_questions) {
   $one_question=$questionsarray[$index];
   $question_text = $one_question->question;
   $row .= ', "' . $question_text . '"';
   $index = $index+1;
}
$row .= "\n";
echo $row;

foreach ($membersarray as $member_guid){
   $member = get_entity($member_guid);
   if (!$form->subgroups){
      $options = array('relationship' => 'form_answer', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_answer', 'order_by' => 'e.time_created desc', 'limit' => 0, 'owner_guid' => $member_guid);
   } else {
      $options = array('relationship' => 'form_answer', 'relationship_guid' => $formpost,'inverse_relationship' => false, 'type' => 'object', 'subtype' => 'form_answer', 'order_by' => 'e.time_created desc', 'limit' => 0, 'container_guid' => $member_guid);
   }
   $user_responses=elgg_get_entities_from_relationship($options);
   $user_response=$user_responses[0];

   if (!empty($user_response)){
      $row =  $member->username;
      $user_response_content_array = explode(Chr(27),$user_response->content);
      $user_response_content_array = array_map('trim', $user_response_content_array);
      $index=0;
      while ($index<$num_questions) {
         $one_question=$questionsarray[$index];
	 $question_guid=$one_question->getGUID();
	 $response_type=$one_question->response_type;
	 if (strcmp($response_type,"text")==0){ 
            $this_response_text=$user_response_content_array[$index];
            if (strcmp($this_response_text,"not_response")==0)
               $this_response_text = "";
	    else 
	       $this_response_text = $this_response_text;
	    $row .= ', "' . $this_response_text . '"';
         } elseif (strcmp($response_type,"html")==0){
            $this_response_html=$user_response_content_array[$index];
            if (strcmp($this_response_html,"not_response")==0)
               $this_response_html = "";
	    else 
	       $this_response_html = html_entity_decode($this_response_html);
	    $row .= ', "' . $this_response_html . '"';
         } elseif ((strcmp($response_type,"radiobutton")==0)||(strcmp($response_type,"checkbox")==0)){ 
            if (strcmp($response_type,"checkbox")==0){
	       if (strcmp($user_response_content_array[$index],"not_response")==0) {
                  $this_responses = "";
	       } else {
	          $this_responses_array = explode(Chr(26),$user_response_content_array[$index]);
                  $this_responses_array = array_map('trim', $this_responses_array);
	          $this_responses = "";
		  foreach ($this_responses_array as $this_response)
	             $this_responses .= $this_response . ' ';
	       }
            } else {
               $this_responses = $user_response_content_array[$index];
	       if (strcmp($this_responses,"not_response")==0)
                  $this_responses = "";
            }
	    $row .=  ', "' . $this_responses . '"';

         } elseif (strcmp($response_type,"grid")==0){
	    $this_responses_grid = "";
            $responses_rows=$one_question->responses_rows;
            $responses_rows_array = explode(Chr(26),$responses_rows);
            $responses_rows_array = array_map('trim', $responses_rows_array);
	    $this_responses = explode(Chr(26),$user_response_content_array[$index]);
            $this_responses = array_map('trim', $this_responses);
            $j=0;
	    foreach ($responses_rows_array as $one_row){ 
	       if (strcmp($this_responses[$j],"not_response")!=0) {
                  $this_responses_grid .= $one_row ." ". $this_responses[$j] ." ";
	       } else {
	          $this_responses_grid .= $one_row ." ";       
	       }
	       $j=$j+1;
            }
	    $row .= ', "' . $this_responses_grid . '"';
         } elseif (strcmp($response_type,"urls_files")==0){
            $this_response_files="";
            if (!$form->subgroups) {
               $response_files = elgg_get_entities_from_relationship(array('relationship' => 'response_file_link','relationship_guid' => $question_guid,'inverse_relationship' => false,'type' => 'object','subtype' => 'form_response_file','owner_guid' => $member_guid,'limit'=>0)); 
            } else {
               $response_files = elgg_get_entities_from_relationship(array('relationship' => 'response_file_link','relationship_guid' => $question_guid,'inverse_relationship' => false,'type' => 'object','subtype' => 'form_response_file','container_guid' => $member_guid,'limit'=>0)); 
            }
            if ((count($response_files)>0)&&(strcmp($response_files[0]->title,"")!=0)){
               foreach($response_files as $file){
                  $this_response_files .= $file->title . " ";
               }    
	    }
	    $row .= ', "' . $this_response_files . '"';
         }
         $index=$index+1;
      }
      $row .= "\n";
      echo $row;
   }
}

exit;

