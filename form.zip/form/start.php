<?php

/**
* Override the ElggFile so that
*/

class ResponsesFormPluginFile extends ElggFile
{
        protected function initialiseAttributes()
        {
                parent::initialise_attributes();
                $this->attributes['subtype'] = "form_response_file";
                $this->attributes['class'] = "ElggFile";
        }

        public function __construct($guid = null)
        {
                if ($guid && !is_object($guid)) {
                   // Loading entities via __construct(GUID) is deprecated, so we give it the entity row and the
                   // attribute loader will finish the job. This is necessary due to not using a custom
                   // subtype (see above).
                   $guid = get_entity_as_row($guid);
                }
                parent::__construct($guid);
        }
}
        
class ZipsFormPluginFile extends ElggFile
{
        protected function initialiseAttributes()
        {
                parent::initialise_attributes();
                $this->attributes['subtype'] = "form_zips_file";
                $this->attributes['class'] = "ElggFile";
        }

        public function __construct($guid = null)
        {
                if ($guid && !is_object($guid)) {
                   // Loading entities via __construct(GUID) is deprecated, so we give it the entity row and the
                   // attribute loader will finish the job. This is necessary due to not using a custom
                   // subtype (see above).
                   $guid = get_entity_as_row($guid);
                }
                parent::__construct($guid);
        }
}


$wwwroot = elgg_get_config('wwwroot');
        
define("FORM_EXPORT_BASEURL",$wwwroot."form");
        
define('FPDF_FONTPATH',dirname(__FILE__)."/lib/fpdf/font/");

include_once(dirname(__FILE__)."/lib/fpdf/fpdf.php");
include_once(dirname(__FILE__)."/lib/fpdf/html2fpdf.php");

function form_init() {
// Extend system CSS with our own styles, which are defined in the form/css view
   elgg_extend_view('css/elgg','form/css');

// Register a page handler, so we can have nice URLs
   elgg_register_page_handler('form','form_page_handler');
                
// Register entity type
   elgg_register_entity_type('object','form');

// Register a URL handler for form posts
   elgg_register_plugin_hook_handler('entity:url','object','form_url');

// Advanced permissions
   elgg_register_plugin_hook_handler('permissions_check', 'object', 'form_permissions_check');

// Not comments to river for form_answer objects
   elgg_register_plugin_hook_handler('creating', 'river', 'form_answer_not_comments_to_river');

// Show forms in groups
   add_group_tool_option('form', elgg_echo('form:enable_group_forms'));
   elgg_extend_view('groups/tool_latest', 'form/group_module');

   elgg_register_plugin_hook_handler('register', 'menu:owner_block', 'form_owner_block_menu');

   run_function_once("form_response_file_add_subtype_run_once"); 

   run_function_once("form_zips_file_add_subtype_run_once"); 

}

function form_response_file_add_subtype_run_once(){
   add_subtype("object","form_response_file","ResponsesFormPluginFile");
}

function form_zips_file_add_subtype_run_once(){
   add_subtype("object","form_zips_file","ZipsFormPluginFile");
}

function form_permissions_check($hook, $type, $return, $params) {
   $user_guid = elgg_get_logged_in_user_guid();
   $group_guid = $params['entity']->container_guid;
   $group = get_entity($group_guid);
   $group_owner_guid = $group->owner_guid;
   $operator=false;
   if (($group_owner_guid==$user_guid)||(check_entity_relationship($user_guid,'group_admin',$group_guid))){
      $operator=true;
   }
   if ((($params['entity']->getSubtype() == 'form')||($params['entity']->getSubtype() == 'form_question')||($params['entity']->getSubtype() == 'form_answer')||($params['entity']->getSubtype() == 'form_answer_file'))&&($operator)) {
      return true;
   }    
}

function form_answer_not_comments_to_river($hook, $type, $params, $return) {
   if ($params['subtype'] == 'form_answer'){
      return false;
   }    
}

/**
 * Add a menu item to the user ownerblock
*/
function form_owner_block_menu($hook, $type, $return, $params) {
   if (elgg_instanceof($params['entity'], 'group')) {
      if ($params['entity']->form_enable != "no") {
         $url = "form/group/{$params['entity']->guid}/all";
         $item = new ElggMenuItem('form', elgg_echo('form:group'), $url);
         $return[] = $item;
      }
   }
   return $return;
}
		
/**
* Form page handler; allows the use of fancy URLs
*
* @param array $page from the page_handler function
* @return true|false depending on success
*/
function form_page_handler($page) {
if (isset($page[0])) {
         elgg_push_breadcrumb(elgg_echo('forms'));
         $base_dir = elgg_get_plugins_path() . 'form/pages/form';
         switch($page[0]) {
            case "add":   
               set_input('container_guid',$page[1]);
               include "$base_dir/add.php"; 
               break;
            case "edit":  
               set_input('formpost',$page[1]);
               include "$base_dir/edit.php"; 
               break;
	    case "add_question":
               set_input('formpost', $page[1]);
               include "$base_dir/add_question.php";
               break;
            case "edit_question":
               set_input('formpost', $page[1]);
               set_input('index',$page[2]);
               include "$base_dir/edit_question.php";
               break;
            case "view":  
               set_input('guid', $page[1]);
               $form = get_entity($page[1]);
               $container = get_entity($form->container_guid);
               set_input('username', $container->username);
               include "$base_dir/read.php"; 
               break;
            case 'group':
               set_input('container_guid',$page[1]);
               include "$base_dir/index.php";
            default:
               return false;
         }
   } else {
      forward();
   }
   return true;
}

/**
* Populates the ->getUrl() method for form objects
*
* @param ElggEntity $formpost form post entity
* @return string form post URL
*/
function form_url($hook, $type, $url, $params) {
  $form = $params['entity'];
  // Check that the entity is a form object
  if ($form->getSubtype() !== 'form') {
    // This is not a form object, so there's no need to go further
    return;
  }
  $title = elgg_get_friendly_title($form->title);
  return $url . "form/view/" . $form->getGUID() . "/" . $title;  
}

function form_answer_url($form_answer) {
   $options = array(
        'relationship' => 'form_answer', 
        'relationship_guid' => $form_answer->getGUID(),
        'inverse_relationship' => true, 
        'type' => 'object', 
        'subtype' => 'form'
   );
   $forms=elgg_get_entities_from_relationship($options);
   if (!empty($forms)){
      $form=$forms[0];
      $title = elgg_get_friendly_title($form->title);
      return $url . 'form/view/' . $form->getGUID() . '/' . $title;     
   } else {
      return false;
   }
}

// Form opened or closed?
function form_check_status($form) {
   if (strcmp($form->option_close_value,'form_close_date')==0){
      $now=time();
      if (($now>=$form->activate_time)&&($now<$form->close_time)){
         return true;
      } else {
         if ($form->action == true){
            $form->option_close_value ='';
            $form->action = false;
            $form->opened = true;
            return true;
         }
         return false;
      }
   } else {
      $form->action = false;
      return $form->opened;
   } 
}

// Make sure the form initialisation function is called on initialisation
elgg_register_event_handler('init','system','form_init');
		
// Register actions
$action_base = elgg_get_plugins_path() . 'form/actions/form';
elgg_register_action("form/add","$action_base/add.php");
elgg_register_action("form/edit","$action_base/edit.php");
elgg_register_action("form/delete","$action_base/delete.php");
elgg_register_action("form/add_question","$action_base/add_question.php");
elgg_register_action("form/edit_question","$action_base/edit_question.php");
elgg_register_action("form/delete_question","$action_base/delete_question.php");
elgg_register_action("form/move_question","$action_base/move_question.php");
elgg_register_action("form/open","$action_base/open.php");
elgg_register_action("form/close","$action_base/close.php");
elgg_register_action("form/publish","$action_base/publish.php");
//elgg_register_action("form/change_visibility","$action_base/change_visibility.php");
elgg_register_action("form/copy","$action_base/copy.php");
elgg_register_action("form/answer","$action_base/answer.php");
elgg_register_action("form/delete_answer","$action_base/delete_answer.php");
elgg_register_action("form/export_pdf","$action_base/export_pdf.php");
elgg_register_action("form/zip","$action_base/zip.php");
elgg_register_action("form/zip_all","$action_base/zip_all.php");
elgg_register_action("form/get_zips","$action_base/get_zips.php");
						
?>